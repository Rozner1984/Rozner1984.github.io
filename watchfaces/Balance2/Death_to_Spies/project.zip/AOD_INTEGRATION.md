# AOD Studio runtime export

This project exports Day, Night and AOD together into watchface/index.js. Day and Night are independent layouts switched by runtime visibility; AOD uses the AOD-specific show_level. app.json enables watchface lockscreen/AOD support. The editor configuration aod-config.json is also included for round-trip editing.

Important: AOD support depends on the target Zepp OS firmware/device. The exporter does not claim unsupported widget APIs.
