import { createWidget, widget, align, text_style, prop, show_level, data_type, system_status } from '@zos/ui'
import { Time, Battery, Step, Calorie, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bg3.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 206, y: 372, w: 100, h: 36, text_size: 23, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_00dd375e85f540a8916032cbe71e82cb_CyrillicHelvet_Bold.ttf", text: "--" });
          const normal_w_1_date_full_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 332, w: 220, h: 40, text_size: 24, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_2_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 72, y: 222, w: 300, h: 100, text_size: 99, color: 0xff0000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_00dd375e85f540a8916032cbe71e82cb_CyrillicHelvet_Bold.ttf", text: "" });
          const normal_w_3_time_second_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 329, y: 254, w: 100, h: 70, text_size: 41, color: 0xf11d1b, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_00dd375e85f540a8916032cbe71e82cb_CyrillicHelvet_Bold.ttf", text: "" });
          createWidget(widget.IMG_STATUS, { show_level: show_level.ONLY_NORMAL,
          x: 63, y: 250, w: 32, h: 32, type: system_status.DISCONNECT, src: "blutus.png" });
          createWidget(widget.IMG_STATUS, { show_level: show_level.ONLY_NORMAL,
          x: 366, y: 231, w: 32, h: 32, type: system_status.CLOCK, src: "budilnik.png" });
          const normal_w_6_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 36, y: 363, w: 150, h: 36, text_size: 34, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_00dd375e85f540a8916032cbe71e82cb_CyrillicHelvet_Bold.ttf", text: "--" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 338, y: 363, w: 120, h: 40, text_size: 34, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_00dd375e85f540a8916032cbe71e82cb_CyrillicHelvet_Bold.ttf", type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_w_8_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 57, y: 174, w: 100, h: 36, text_size: 35, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_00dd375e85f540a8916032cbe71e82cb_CyrillicHelvet_Bold.ttf", text: "--" });
          const normal_w_9_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 342, y: 177, w: 120, h: 32, text_size: 34, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_00dd375e85f540a8916032cbe71e82cb_CyrillicHelvet_Bold.ttf", text: "--" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_1_date_full_001.setProperty(prop.MORE, { text: formatDate(now, "DD.MM.YYYY", "RU") });
            normal_w_2_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            normal_w_3_time_second_001.setProperty(prop.MORE, { text: formatUnit(now.getSeconds(), true) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_0_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_0_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_6_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_6_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_8_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_8_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_9_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_9_calories_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const __bgImage_aod_ = createWidget(widget.IMG, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, src: "aod_bg.png" });
          __bgImage_aod_.setAlpha(255);
          const aod_w_0_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 30, y: 190, w: 400, h: 260, text_size: 117, color: 0xf11d1b, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_00dd375e85f540a8916032cbe71e82cb_CyrillicHelvet_Bold.ttf", text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
