import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time, Battery, Step, Calorie, Weather, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _weatherFc = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "rossiya.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 100, y: 120, w: 300, h: 117, text_size: 97, color: 0x038cfe, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_1_time_second_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 360, y: 124, w: 100, h: 70, text_size: 48, color: 0xe41111, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_2_date_day_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 204, y: 216, w: 80, h: 40, text_size: 30, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_3_weekday_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 248, y: 218, w: 120, h: 36, text_size: 30, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_4_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 330, w: 100, h: 42, text_size: 35, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_5_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 223, y: 330, w: 120, h: 42, text_size: 35, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_6_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 341, y: 330, w: 150, h: 42, text_size: 35, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          // Набор картинок (BATTERY): 6 кадр(ов), крайние кадры на краях диапазона
          const normal_w_7_image_set_001_frames = ["akb6_2.png","akb5_2.png","akb4_2.png","akb3_2.png","akb2_2.png","akb1_2.png"];
          const normal_w_7_image_set_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 380, y: 198, w: 15, h: 30, src: normal_w_7_image_set_001_frames[3] });
          let normal_w_7_image_set_001_cur = -1;
          function normal_w_7_image_set_001_set(r) {
            r = (typeof r === 'number' && isFinite(r)) ? Math.max(0, Math.min(1, r)) : 0;
            const i = Math.round(r * 5);
            if (i === normal_w_7_image_set_001_cur) return;
            normal_w_7_image_set_001_cur = i;
            try { normal_w_7_image_set_001.setProperty(prop.MORE, { src: normal_w_7_image_set_001_frames[i] }); } catch (e) {}
          }
          const normal_w_8_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 403, y: 199, w: 100, h: 36, text_size: 25, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_9_weather_forecast_icon_001_weatherFiles = ["weather/50x50/0_cloudy.png","weather/50x50/1_showers.png","weather/50x50/2_snow_showers.png","weather/50x50/3_sunny.png","weather/50x50/4_overcast.png","weather/50x50/5_light_rain.png","weather/50x50/6_light_snow.png","weather/50x50/7_moderate_rain.png","weather/50x50/8_moderate_snow.png","weather/50x50/9_heavy_snow.png","weather/50x50/10_heavy_rain.png","weather/50x50/11_sandstorm.png","weather/50x50/12_rain_snow.png","weather/50x50/13_fog.png","weather/50x50/14_hazy.png","weather/50x50/15_thunderstorm.png","weather/50x50/16_snowstorm.png","weather/50x50/17_floating_dust.png","weather/50x50/18_very_heavy_rainstorm.png","weather/50x50/19_rain_hail.png","weather/50x50/20_thunderstorm_hail.png","weather/50x50/21_heavy_rainstorm.png","weather/50x50/22_dust.png","weather/50x50/23_heavy_sandstorm.png","weather/50x50/24_rainstorm.png","weather/50x50/25_unknown.png","weather/50x50/26_cloudy_night.png","weather/50x50/27_showers_night.png","weather/50x50/28_sunny_night.png"];
          const normal_w_9_weather_forecast_icon_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 176, y: 380, w: 50, h: 50, src: "weather/50x50/3_sunny.png" });
          normal_w_9_weather_forecast_icon_001.setAlpha(255);
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 230, y: 384, w: 120, h: 51, text_size: 40, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_w_11_arc_001 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, start_angle: -90, end_angle: -90, color: 0xff0000, line_width: 7, corner_flag: 1 });
          // Дуга normal_w_11_arc_001: значение из источника SECOND, углы на часах -90°…269° (0° = 3 часа)
          let normal_w_11_arc_001_target = 0, normal_w_11_arc_001_phase = 2, normal_w_11_arc_001_timer = null, normal_w_11_arc_001_err = false;
          function normal_w_11_arc_001_draw(r, f, g) {
            try {
              normal_w_11_arc_001.setProperty(prop.MORE, { x: 0, y: 0, w: 480, h: 480, start_angle: -90, end_angle: Math.round(-90 + (359) * r), color: 0xff0000, line_width: 7 });
            } catch (e) { if (!normal_w_11_arc_001_err) { normal_w_11_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_11_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_11_arc_001_target = v;
            normal_w_11_arc_001_draw(v, 1, 1);
          }
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _weatherFc = new Weather(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_0_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            normal_w_1_time_second_001.setProperty(prop.MORE, { text: formatUnit(now.getSeconds(), true) });
            normal_w_2_date_day_001.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            normal_w_3_weekday_001.setProperty(prop.MORE, { text: formatWeekday(now, "EEE3", "RU") });
            normal_w_11_arc_001_set(now.getSeconds() / 60);
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_4_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_4_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_5_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_5_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_6_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_6_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_7_image_set_001_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { normal_w_7_image_set_001_set(0); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_8_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_8_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const fc = _weatherFc ? _weatherFc.getForecast() : null;
              const it = (fc && fc.forecastData && fc.forecastData.data) ? fc.forecastData.data[1] : null;
              if (it && typeof it.index === 'number' && normal_w_9_weather_forecast_icon_001_weatherFiles[it.index]) normal_w_9_weather_forecast_icon_001.setProperty(prop.MORE, { src: normal_w_9_weather_forecast_icon_001_weatherFiles[it.index] });
            } catch (e) {}
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
