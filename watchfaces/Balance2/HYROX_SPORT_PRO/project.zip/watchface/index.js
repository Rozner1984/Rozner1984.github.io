import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time, Battery, Step, Calorie, Distance, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _distance = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "img_3831.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_arc_001_a = [-445, -433, -422, -410, -398, -386, -375, -363, -351, -340, -328, -316, -305, -293, -281, -269, -258, -246, -234, -223, -211, -199, -188, -176, -164, -152, -141, -129, -117, -106], normal_w_0_arc_001_b = [-434, -423, -411, -399, -387, -376, -364, -352, -341, -329, -317, -306, -294, -282, -271, -259, -247, -235, -224, -212, -200, -189, -177, -165, -154, -142, -130, -118, -107, -95], normal_w_0_arc_001_c = [0x2ed600, 0x32cf00, 0x35c800, 0x39c100, 0x3cba01, 0x40b401, 0x43ad01, 0x47a601, 0x4a9f01, 0x4e9801, 0x529101, 0x558a02, 0x598302, 0x5c7c02, 0x607502, 0x636f02, 0x676802, 0x6a6102, 0x6e5a02, 0x715303, 0x754c03, 0x794503, 0x7c3e03, 0x803703, 0x833003, 0x872a03, 0x8a2304, 0x8e1c04, 0x911504, 0x950e04];
          const normal_w_0_arc_001_trk = [];
          for (let normal_w_0_arc_001_ti = 0; normal_w_0_arc_001_ti < 30; normal_w_0_arc_001_ti++) {
            normal_w_0_arc_001_trk.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 3, y: 3, w: 474, h: 474, start_angle: normal_w_0_arc_001_a[normal_w_0_arc_001_ti], end_angle: normal_w_0_arc_001_b[normal_w_0_arc_001_ti], color: 0x2a3042, line_width: 8 }));
          }
          const normal_w_0_arc_001_segs = [], normal_w_0_arc_001_vis = [];
          for (let normal_w_0_arc_001_i = 0; normal_w_0_arc_001_i < 30; normal_w_0_arc_001_i++) {
            normal_w_0_arc_001_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 3, y: 3, w: 474, h: 474, start_angle: normal_w_0_arc_001_a[normal_w_0_arc_001_i], end_angle: normal_w_0_arc_001_a[normal_w_0_arc_001_i], color: normal_w_0_arc_001_c[normal_w_0_arc_001_i], line_width: 8 }));
            normal_w_0_arc_001_vis[normal_w_0_arc_001_i] = false;
            if (!normal_w_0_arc_001_vis[normal_w_0_arc_001_i]) normal_w_0_arc_001_segs[normal_w_0_arc_001_i].setProperty(prop.VISIBLE, false);
          }
          // Дуга normal_w_0_arc_001: значение из источника BATTERY, углы на часах -445°…-95° (0° = 3 часа)
          let normal_w_0_arc_001_target = 0, normal_w_0_arc_001_phase = 0, normal_w_0_arc_001_timer = null, normal_w_0_arc_001_err = false;
          const normal_w_0_arc_001_last = [];
          function normal_w_0_arc_001_draw(r, f, g) {
            try {
              const cur = -445 + (350) * r;
              const lw = 8;
              for (let normal_w_0_arc_001_k = 0; normal_w_0_arc_001_k < 30; normal_w_0_arc_001_k++) {
                const a = normal_w_0_arc_001_a[normal_w_0_arc_001_k], b = normal_w_0_arc_001_b[normal_w_0_arc_001_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));   // граница заполнения внутри сегмента
                const col = normal_w_0_arc_001_c[normal_w_0_arc_001_k];
                const key = end + ':' + col + ':' + lw;
                if (normal_w_0_arc_001_last[normal_w_0_arc_001_k] === key) continue;
                normal_w_0_arc_001_last[normal_w_0_arc_001_k] = key;
                if (end === a) { if (normal_w_0_arc_001_vis[normal_w_0_arc_001_k]) { normal_w_0_arc_001_vis[normal_w_0_arc_001_k] = false; normal_w_0_arc_001_segs[normal_w_0_arc_001_k].setProperty(prop.VISIBLE, false); } continue; }
                normal_w_0_arc_001_segs[normal_w_0_arc_001_k].setProperty(prop.MORE, { x: 3, y: 3, w: 474, h: 474, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!normal_w_0_arc_001_vis[normal_w_0_arc_001_k]) { normal_w_0_arc_001_vis[normal_w_0_arc_001_k] = true; normal_w_0_arc_001_segs[normal_w_0_arc_001_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_0_arc_001_err) { normal_w_0_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_0_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_0_arc_001_target = v;
            if (normal_w_0_arc_001_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_0_arc_001_phase === 0) { normal_w_0_arc_001_phase = 1; normal_w_0_arc_001_run(); return; }
            normal_w_0_arc_001_draw(v, 1, 1);
          }
          function normal_w_0_arc_001_run() {
            let n = 0;
            normal_w_0_arc_001_draw(0, 0, 0);
            normal_w_0_arc_001_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = k;
              normal_w_0_arc_001_draw((k < 0.5 ? 2 * k : 1 - (1 - normal_w_0_arc_001_target) * 2 * k - 1), 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_0_arc_001_timer); normal_w_0_arc_001_timer = null; normal_w_0_arc_001_phase = 2;
                normal_w_0_arc_001_draw(normal_w_0_arc_001_target, 1, 1);
              }
            }, 40);
          }
          const normal_w_1_text_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: -33, y: 230, w: 200, h: 50, text_size: 40, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c0788c08097a4d1cb547c4a1ea67ed63_Machine_BT.ttf", text: "--" });
          const normal_w_2_text_003 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 310, y: 231, w: 200, h: 50, text_size: 40, color: 0xf1ecf3, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c0788c08097a4d1cb547c4a1ea67ed63_Machine_BT.ttf", text: "--" });
          const normal_w_3_distance_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 53, y: 376, w: 120, h: 32, text_size: 35, color: 0xffffff, align_h: align.RIGHT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c0788c08097a4d1cb547c4a1ea67ed63_Machine_BT.ttf", text: "--" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 270, y: 374, w: 120, h: 40, text_size: 35, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c0788c08097a4d1cb547c4a1ea67ed63_Machine_BT.ttf", type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_w_5_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 207, w: 300, h: 100, text_size: 102, color: 0xebd90f, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_9fd9d18b19ea4af0bce99c3ece53b37a_AlienEncountersSolidRegular.ttf", text: "" });
          const normal_w_6_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 241, y: 152, w: 100, h: 36, text_size: 35, color: 0xf2ae01, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c0788c08097a4d1cb547c4a1ea67ed63_Machine_BT.ttf", text: "--" });
          const normal_w_7_time_second_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 190, y: 271, w: 100, h: 70, text_size: 35, color: 0xe9a601, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c0788c08097a4d1cb547c4a1ea67ed63_Machine_BT.ttf", text: "" });
          const normal_w_8_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 194, y: 55, w: 100, h: 36, text_size: 30, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c0788c08097a4d1cb547c4a1ea67ed63_Machine_BT.ttf", text: "--" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 330, y: 94, w: 80, h: 40, text_size: 34, color: 0xecab02, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.RECOVERY_TIME, unit_type: 1 });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 156, y: 372, w: 168, h: 47, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c0788c08097a4d1cb547c4a1ea67ed63_Machine_BT.ttf", type: data_type.READINESS, unit_type: 0 });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _distance = new Distance(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_5_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            normal_w_7_time_second_001.setProperty(prop.MORE, { text: formatUnit(now.getSeconds(), true) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_0_arc_001_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { normal_w_0_arc_001_set(0); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_1_text_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_1_text_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_2_text_003.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_2_text_003.setProperty(prop.MORE, { text: '--' }); }
            try {
              const raw = _distance ? _distance.getCurrent() : null;
              // Единица возвращаемого значения в документации не указана (⚠) — принята за метры.
              let v = typeof raw === 'number' ? raw / 1000 : null;
              const txt = v !== null ? v.toFixed(2) : '--';
              normal_w_3_distance_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_distance_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_6_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_6_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_8_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_8_battery_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 91, y: 170, w: 300, h: 100, text_size: 102, color: 0xebd90f, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_9fd9d18b19ea4af0bce99c3ece53b37a_AlienEncountersSolidRegular.ttf", text: "" });
          const aod_w_1_arc_001_a = [-445, -433, -422, -410, -398, -386, -375, -363, -351, -340, -328, -316, -305, -293, -281, -269, -258, -246, -234, -223, -211, -199, -188, -176, -164, -152, -141, -129, -117, -106], aod_w_1_arc_001_b = [-434, -423, -411, -399, -387, -376, -364, -352, -341, -329, -317, -306, -294, -282, -271, -259, -247, -235, -224, -212, -200, -189, -177, -165, -154, -142, -130, -118, -107, -95], aod_w_1_arc_001_c = [0x2ed600, 0x32cf00, 0x35c800, 0x39c100, 0x3cba01, 0x40b401, 0x43ad01, 0x47a601, 0x4a9f01, 0x4e9801, 0x529101, 0x558a02, 0x598302, 0x5c7c02, 0x607502, 0x636f02, 0x676802, 0x6a6102, 0x6e5a02, 0x715303, 0x754c03, 0x794503, 0x7c3e03, 0x803703, 0x833003, 0x872a03, 0x8a2304, 0x8e1c04, 0x911504, 0x950e04];
          const aod_w_1_arc_001_trk = [];
          for (let aod_w_1_arc_001_ti = 0; aod_w_1_arc_001_ti < 30; aod_w_1_arc_001_ti++) {
            aod_w_1_arc_001_trk.push(createWidget(widget.ARC, { show_level: show_level.ONAL_AOD,
          x: 3, y: 3, w: 474, h: 474, start_angle: aod_w_1_arc_001_a[aod_w_1_arc_001_ti], end_angle: aod_w_1_arc_001_b[aod_w_1_arc_001_ti], color: 0x2a3042, line_width: 8 }));
          }
          const aod_w_1_arc_001_segs = [], aod_w_1_arc_001_vis = [];
          for (let aod_w_1_arc_001_i = 0; aod_w_1_arc_001_i < 30; aod_w_1_arc_001_i++) {
            aod_w_1_arc_001_segs.push(createWidget(widget.ARC, { show_level: show_level.ONAL_AOD,
          x: 3, y: 3, w: 474, h: 474, start_angle: aod_w_1_arc_001_a[aod_w_1_arc_001_i], end_angle: aod_w_1_arc_001_a[aod_w_1_arc_001_i], color: aod_w_1_arc_001_c[aod_w_1_arc_001_i], line_width: 8 }));
            aod_w_1_arc_001_vis[aod_w_1_arc_001_i] = false;
            if (!aod_w_1_arc_001_vis[aod_w_1_arc_001_i]) aod_w_1_arc_001_segs[aod_w_1_arc_001_i].setProperty(prop.VISIBLE, false);
          }
          // Дуга aod_w_1_arc_001: значение из источника BATTERY, углы на часах -445°…-95° (0° = 3 часа)
          let aod_w_1_arc_001_target = 0, aod_w_1_arc_001_phase = 2, aod_w_1_arc_001_timer = null, aod_w_1_arc_001_err = false;
          const aod_w_1_arc_001_last = [];
          function aod_w_1_arc_001_draw(r, f, g) {
            try {
              const cur = -445 + (350) * r;
              const lw = 8;
              for (let aod_w_1_arc_001_k = 0; aod_w_1_arc_001_k < 30; aod_w_1_arc_001_k++) {
                const a = aod_w_1_arc_001_a[aod_w_1_arc_001_k], b = aod_w_1_arc_001_b[aod_w_1_arc_001_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));   // граница заполнения внутри сегмента
                const col = aod_w_1_arc_001_c[aod_w_1_arc_001_k];
                const key = end + ':' + col + ':' + lw;
                if (aod_w_1_arc_001_last[aod_w_1_arc_001_k] === key) continue;
                aod_w_1_arc_001_last[aod_w_1_arc_001_k] = key;
                if (end === a) { if (aod_w_1_arc_001_vis[aod_w_1_arc_001_k]) { aod_w_1_arc_001_vis[aod_w_1_arc_001_k] = false; aod_w_1_arc_001_segs[aod_w_1_arc_001_k].setProperty(prop.VISIBLE, false); } continue; }
                aod_w_1_arc_001_segs[aod_w_1_arc_001_k].setProperty(prop.MORE, { x: 3, y: 3, w: 474, h: 474, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!aod_w_1_arc_001_vis[aod_w_1_arc_001_k]) { aod_w_1_arc_001_vis[aod_w_1_arc_001_k] = true; aod_w_1_arc_001_segs[aod_w_1_arc_001_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!aod_w_1_arc_001_err) { aod_w_1_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function aod_w_1_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            aod_w_1_arc_001_target = v;
            aod_w_1_arc_001_draw(v, 1, 1);
          }
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
          function _tickSensorsAod() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              aod_w_1_arc_001_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { aod_w_1_arc_001_set(0); }
          }
          _tickSensorsAod();
          self._sensorTimerAod = setInterval(_tickSensorsAod, 5000);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
