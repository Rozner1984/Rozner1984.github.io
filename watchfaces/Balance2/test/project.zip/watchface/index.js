import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Battery } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _battery = null;

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const normal_w_0_arc_005_track = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 2, y: 1, w: 476, h: 477, start_angle: -210, end_angle: 30, color: 0x575757, line_width: 6, corner_flag: 1 });
          try { normal_w_0_arc_005_track.setAlpha(232); } catch (e) {}
          const normal_w_0_arc_005 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 2, y: 1, w: 476, h: 477, start_angle: -210, end_angle: -210, color: 0xff3352, line_width: 6, corner_flag: 1 });
          // Дуга normal_w_0_arc_005: значение из источника BATTERY, углы на часах -210°…30° (0° = 3 часа)
          let normal_w_0_arc_005_target = 0, normal_w_0_arc_005_phase = 0, normal_w_0_arc_005_timer = null, normal_w_0_arc_005_err = false;
          function normal_w_0_arc_005_draw(r, f, g) {
            try {
              normal_w_0_arc_005.setProperty(prop.MORE, { x: 2, y: 1, w: 476, h: 477, start_angle: -210, end_angle: Math.round(-210 + (240) * r), color: 0xff3352, line_width: 6 });
            } catch (e) { if (!normal_w_0_arc_005_err) { normal_w_0_arc_005_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_0_arc_005_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_0_arc_005_target = v;
            if (normal_w_0_arc_005_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_0_arc_005_phase === 0) { normal_w_0_arc_005_phase = 1; normal_w_0_arc_005_run(); return; }
            normal_w_0_arc_005_draw(v, 1, 1);
          }
          function normal_w_0_arc_005_run() {
            let n = 0;
            normal_w_0_arc_005_draw(0, 0, 0);
            normal_w_0_arc_005_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = k;
              normal_w_0_arc_005_draw((k < 0.5 ? 2 * k : 1 - (1 - normal_w_0_arc_005_target) * 2 * k - 1), 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_0_arc_005_timer); normal_w_0_arc_005_timer = null; normal_w_0_arc_005_phase = 2;
                normal_w_0_arc_005_draw(normal_w_0_arc_005_target, 1, 1);
              }
            }, 40);
          }
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _battery = new Battery(); } catch (e) {}
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_0_arc_005_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { normal_w_0_arc_005_set(0); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
