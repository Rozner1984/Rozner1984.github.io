import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time, Battery, Step, Calorie, Distance, Weather, HeartRate, Screen } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _distance = null;
let _weatherFc = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bg6.png" });
          __bgImage_normal_.setAlpha(255);
          // Контур/тень дуги: строка слоя = [расширение с каждой стороны, dx, dy, цвет, прозрачность 0–255, выступ за концы в градусах]
          const normal_w_0_arc_001_dl = [[4, 0, 3, 0x333333, 77, 0], [0, 0, 3, 0x333333, 77, 0]];
          const normal_w_0_arc_001_dec = [], normal_w_0_arc_001_dvis = [];
          for (let normal_w_0_arc_001_di = 0; normal_w_0_arc_001_di < 2; normal_w_0_arc_001_di++) {
            const d = normal_w_0_arc_001_dl[normal_w_0_arc_001_di];
            normal_w_0_arc_001_dec.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 1 + d[1] - d[0], y: 2 + d[2] - d[0], w: 477 + 2 * d[0], h: 477 + 2 * d[0], start_angle: -230 - (1) * d[5], end_angle: 129 + (1) * d[5], color: d[3], line_width: 8 + 2 * d[0], corner_flag: 1 }));
            normal_w_0_arc_001_dvis[normal_w_0_arc_001_di] = false;
            normal_w_0_arc_001_dec[normal_w_0_arc_001_di].setProperty(prop.VISIBLE, false);
            try { if (d[4] < 255) normal_w_0_arc_001_dec[normal_w_0_arc_001_di].setAlpha(d[4]); } catch (e) {}
          }
          const normal_w_0_arc_001 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 1, y: 2, w: 477, h: 477, start_angle: -230, end_angle: -230, color: 0x05eb74, line_width: 8, corner_flag: 1 });
          function normal_w_0_arc_001_decDraw(r, f, g) {
            const lw = 8;
            const p0 = -230, q0 = Math.round(-230 + (359) * r);
            for (let k = 0; k < 2; k++) {
              const d = normal_w_0_arc_001_dl[k], wd = normal_w_0_arc_001_dec[k];
              if (r <= 0) { if (normal_w_0_arc_001_dvis[k]) { normal_w_0_arc_001_dvis[k] = false; wd.setProperty(prop.VISIBLE, false); } continue; }
              wd.setProperty(prop.MORE, { x: 1 + d[1] - d[0], y: 2 + d[2] - d[0], w: 477 + 2 * d[0], h: 477 + 2 * d[0], start_angle: p0 - (1) * d[5], end_angle: q0 + (1) * d[5], color: d[3], line_width: lw + 2 * d[0] });
              if (!normal_w_0_arc_001_dvis[k]) { normal_w_0_arc_001_dvis[k] = true; wd.setProperty(prop.VISIBLE, true); }
            }
          }
          // Дуга normal_w_0_arc_001: значение из источника BATTERY, углы на часах -230°…129° (0° = 3 часа)
          let normal_w_0_arc_001_target = 0, normal_w_0_arc_001_phase = 0, normal_w_0_arc_001_timer = null, normal_w_0_arc_001_err = false;
          function normal_w_0_arc_001_draw(r, f, g) {
            try {
              normal_w_0_arc_001_decDraw(r, f, g);
              normal_w_0_arc_001.setProperty(prop.MORE, { x: 1, y: 2, w: 477, h: 477, start_angle: -230, end_angle: Math.round(-230 + (359) * r), color: 0x05eb74, line_width: 8 });
            } catch (e) { if (!normal_w_0_arc_001_err) { normal_w_0_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_0_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_0_arc_001_target = v;
            if (normal_w_0_arc_001_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_0_arc_001_phase === 0) { normal_w_0_arc_001_phase = 1; normal_w_0_arc_001_run(); return; }
            normal_w_0_arc_001_draw(v, 1, 1);
          }
          function normal_w_0_arc_001_run() {
            let n = 0;
            normal_w_0_arc_001_draw(0, 0, 0);
            normal_w_0_arc_001_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = k;
              normal_w_0_arc_001_draw((k < 0.5 ? 2 * k : 1 - (1 - normal_w_0_arc_001_target) * 2 * k - 1), 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_0_arc_001_timer); normal_w_0_arc_001_timer = null; normal_w_0_arc_001_phase = 2;
                normal_w_0_arc_001_draw(normal_w_0_arc_001_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_0_arc_001_replay() {
            if (normal_w_0_arc_001_phase !== 2) return;
            normal_w_0_arc_001_phase = 1;
            normal_w_0_arc_001_run();
          }
          const normal_w_1_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 99, y: 61, w: 210, h: 40, text_size: 35, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "--" });
          const normal_w_2_distance_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 250, y: 61, w: 120, h: 32, text_size: 35, color: 0xffffff, align_h: align.RIGHT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "--" });
          const normal_w_3_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 220, y: 95, w: 100, h: 36, text_size: 35, color: 0xcc8b19, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "--" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 9, y: 225, w: 120, h: 40, text_size: 35, color: 0xffffff, align_h: align.RIGHT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", type: data_type.WEATHER_CURRENT, unit_type: 0 });
          const normal_w_5_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 85, y: 376, w: 100, h: 36, text_size: 35, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "--" });
          const normal_w_6_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 270, y: 376, w: 120, h: 32, text_size: 35, color: 0xffffff, align_h: align.RIGHT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "--" });
          const normal_w_7_weekday_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 128, y: 326, w: 210, h: 30, text_size: 24, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_8_date_month_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 122, y: 400, w: 220, h: 40, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "" });
          const normal_w_9_date_day_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 192, y: 364, w: 80, h: 40, text_size: 48, color: 0xea7d16, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "" });
          const normal_w_10_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 180, y: 180, w: 300, h: 130, text_size: 137, color: 0xfe7c02, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "" });
          const normal_w_11_weather_forecast_icon_001_weatherFiles = ["weather/64x64/0_cloudy.png","weather/64x64/1_showers.png","weather/64x64/2_snow_showers.png","weather/64x64/3_sunny.png","weather/64x64/4_overcast.png","weather/64x64/5_light_rain.png","weather/64x64/6_light_snow.png","weather/64x64/7_moderate_rain.png","weather/64x64/8_moderate_snow.png","weather/64x64/9_heavy_snow.png","weather/64x64/10_heavy_rain.png","weather/64x64/11_sandstorm.png","weather/64x64/12_rain_snow.png","weather/64x64/13_fog.png","weather/64x64/14_hazy.png","weather/64x64/15_thunderstorm.png","weather/64x64/16_snowstorm.png","weather/64x64/17_floating_dust.png","weather/64x64/18_very_heavy_rainstorm.png","weather/64x64/19_rain_hail.png","weather/64x64/20_thunderstorm_hail.png","weather/64x64/21_heavy_rainstorm.png","weather/64x64/22_dust.png","weather/64x64/23_heavy_sandstorm.png","weather/64x64/24_rainstorm.png","weather/64x64/25_unknown.png","weather/64x64/26_cloudy_night.png","weather/64x64/27_showers_night.png","weather/64x64/28_sunny_night.png"];
          const normal_w_11_weather_forecast_icon_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 20, y: 215, w: 64, h: 64, src: "weather/64x64/6_light_snow.png" });
          normal_w_11_weather_forecast_icon_001.setAlpha(255);
      
          // Повтор анимации дуг при возврате на циферблат / пробуждении экрана
          try {
            createWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { console.log('watchface resume'); } catch (e) {}
                try { normal_w_0_arc_001_replay(); } catch (e) {}
              },
              pause_call: function () {},
            });
          } catch (e) {}
      
          // Повтор анимации дуг при поднятии руки (Screen.onChange + страховка по паузе таймера)
          try {
            const _scr = new Screen();
            let _scrPrev = 1;
            try { _scrPrev = _scr.getStatus(); } catch (e) {}
            const _raise = function (why) {
              try { console.log('arc replay: ' + why); } catch (e) {}
              try { normal_w_0_arc_001_replay(); } catch (e) {}
            };
            self._screen = _scr;
            self._screenCb = function (st) {
              try {
                const cur = (typeof st === 'number') ? st : _scr.getStatus();
                try { console.log('screen status: ' + cur); } catch (e) {}
                const was = _scrPrev; _scrPrev = cur;
                if (cur === 1 && was !== 1) _raise('screen on');
              } catch (e) {}
            };
            _scr.onChange(self._screenCb);
            let _hbLast = Date.now();
            self._raiseTimer = setInterval(function () {
              try {
                const t = Date.now();
                if (t - _hbLast > 3000) _raise('timer gap ' + (t - _hbLast) + ' ms');
                _hbLast = t;
              } catch (e) {}
            }, 1000);
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _distance = new Distance(); } catch (e) {}
          try { _weatherFc = new Weather(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_7_weekday_001.setProperty(prop.MORE, { text: formatWeekday(now, "EEEE", "RU") });
            normal_w_8_date_month_001.setProperty(prop.MORE, { text: formatMonth(now, "MMMM", "RU") });
            normal_w_9_date_day_001.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            normal_w_10_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_0_arc_001_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { normal_w_0_arc_001_set(0); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_1_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_1_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const raw = _distance ? _distance.getCurrent() : null;
              // Единица возвращаемого значения в документации не указана (⚠) — принята за метры.
              let v = typeof raw === 'number' ? raw / 1000 : null;
              const txt = v !== null ? v.toFixed(2) : '--';
              normal_w_2_distance_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_2_distance_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_3_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_5_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_5_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_6_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_6_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const fc = _weatherFc ? _weatherFc.getForecast() : null;
              const it = (fc && fc.forecastData && fc.forecastData.data) ? fc.forecastData.data[1] : null;
              if (it && typeof it.index === 'number' && normal_w_11_weather_forecast_icon_001_weatherFiles[it.index]) normal_w_11_weather_forecast_icon_001.setProperty(prop.MORE, { src: normal_w_11_weather_forecast_icon_001_weatherFiles[it.index] });
            } catch (e) {}
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_arc_001_a = [-230, -213, -196, -178, -161, -144, -127, -110, -92, -75, -58, -41, -24, -7, 11, 28, 45, 62, 79, 97, 114], aod_w_0_arc_001_b = [-217, -200, -182, -165, -148, -131, -114, -96, -79, -62, -45, -28, -11, 7, 24, 41, 58, 75, 93, 110, 127], aod_w_0_arc_001_c = [0xff0000, 0xfa0d04, 0xf41a07, 0xef260b, 0xe9330e, 0xe44012, 0xde4d15, 0xd95919, 0xd3661c, 0xce7320, 0xc88024, 0xc38c27, 0xbd992b, 0xb8a62e, 0xb2b332, 0xadbf35, 0xa7cc39, 0xa2d93c, 0x9ce640, 0x97f243, 0x91ff47];
          // Контур/тень дуги: строка слоя = [расширение с каждой стороны, dx, dy, цвет, прозрачность 0–255, выступ за концы в градусах]
          const aod_w_0_arc_001_dl = [[4, 0, 3, 0x333333, 77, 0], [0, 0, 3, 0x333333, 77, 0]];
          const aod_w_0_arc_001_dec = [], aod_w_0_arc_001_dvis = [];
          for (let aod_w_0_arc_001_di = 0; aod_w_0_arc_001_di < 2; aod_w_0_arc_001_di++) {
            const d = aod_w_0_arc_001_dl[aod_w_0_arc_001_di];
            aod_w_0_arc_001_dec.push(createWidget(widget.ARC, { show_level: show_level.ONAL_AOD,
          x: 1 + d[1] - d[0], y: 2 + d[2] - d[0], w: 477 + 2 * d[0], h: 477 + 2 * d[0], start_angle: -230 - (1) * d[5], end_angle: 127 + (1) * d[5], color: d[3], line_width: 7 + 2 * d[0], corner_flag: 1 }));
            aod_w_0_arc_001_dvis[aod_w_0_arc_001_di] = false;
            aod_w_0_arc_001_dec[aod_w_0_arc_001_di].setProperty(prop.VISIBLE, false);
            try { if (d[4] < 255) aod_w_0_arc_001_dec[aod_w_0_arc_001_di].setAlpha(d[4]); } catch (e) {}
          }
          const aod_w_0_arc_001_segs = [], aod_w_0_arc_001_vis = [];
          for (let aod_w_0_arc_001_i = 0; aod_w_0_arc_001_i < 21; aod_w_0_arc_001_i++) {
            aod_w_0_arc_001_segs.push(createWidget(widget.ARC, { show_level: show_level.ONAL_AOD,
          x: 1, y: 2, w: 477, h: 477, start_angle: aod_w_0_arc_001_a[aod_w_0_arc_001_i], end_angle: aod_w_0_arc_001_a[aod_w_0_arc_001_i], color: aod_w_0_arc_001_c[aod_w_0_arc_001_i], line_width: 7, corner_flag: 1 }));
            aod_w_0_arc_001_vis[aod_w_0_arc_001_i] = false;
            if (!aod_w_0_arc_001_vis[aod_w_0_arc_001_i]) aod_w_0_arc_001_segs[aod_w_0_arc_001_i].setProperty(prop.VISIBLE, false);
          }
          function aod_w_0_arc_001_decDraw(r, f, g) {
            const lw = 7;
            const p0 = -230, q0 = Math.round(-230 + (357) * r);
            for (let k = 0; k < 2; k++) {
              const d = aod_w_0_arc_001_dl[k], wd = aod_w_0_arc_001_dec[k];
              if (r <= 0) { if (aod_w_0_arc_001_dvis[k]) { aod_w_0_arc_001_dvis[k] = false; wd.setProperty(prop.VISIBLE, false); } continue; }
              wd.setProperty(prop.MORE, { x: 1 + d[1] - d[0], y: 2 + d[2] - d[0], w: 477 + 2 * d[0], h: 477 + 2 * d[0], start_angle: p0 - (1) * d[5], end_angle: q0 + (1) * d[5], color: d[3], line_width: lw + 2 * d[0] });
              if (!aod_w_0_arc_001_dvis[k]) { aod_w_0_arc_001_dvis[k] = true; wd.setProperty(prop.VISIBLE, true); }
            }
          }
          // Дуга aod_w_0_arc_001: значение из источника BATTERY, углы на часах -230°…127° (0° = 3 часа)
          let aod_w_0_arc_001_target = 0, aod_w_0_arc_001_phase = 2, aod_w_0_arc_001_timer = null, aod_w_0_arc_001_err = false;
          const aod_w_0_arc_001_last = [];
          function aod_w_0_arc_001_draw(r, f, g) {
            try {
              aod_w_0_arc_001_decDraw(r, f, g);
              const cur = -230 + (357) * r;
              const lw = 7;
              for (let aod_w_0_arc_001_k = 0; aod_w_0_arc_001_k < 21; aod_w_0_arc_001_k++) {
                const a = aod_w_0_arc_001_a[aod_w_0_arc_001_k], b = aod_w_0_arc_001_b[aod_w_0_arc_001_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));   // граница заполнения внутри сегмента
                const col = aod_w_0_arc_001_c[aod_w_0_arc_001_k];
                const key = end + ':' + col + ':' + lw;
                if (aod_w_0_arc_001_last[aod_w_0_arc_001_k] === key) continue;
                aod_w_0_arc_001_last[aod_w_0_arc_001_k] = key;
                if (end === a) { if (aod_w_0_arc_001_vis[aod_w_0_arc_001_k]) { aod_w_0_arc_001_vis[aod_w_0_arc_001_k] = false; aod_w_0_arc_001_segs[aod_w_0_arc_001_k].setProperty(prop.VISIBLE, false); } continue; }
                aod_w_0_arc_001_segs[aod_w_0_arc_001_k].setProperty(prop.MORE, { x: 1, y: 2, w: 477, h: 477, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!aod_w_0_arc_001_vis[aod_w_0_arc_001_k]) { aod_w_0_arc_001_vis[aod_w_0_arc_001_k] = true; aod_w_0_arc_001_segs[aod_w_0_arc_001_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!aod_w_0_arc_001_err) { aod_w_0_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function aod_w_0_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            aod_w_0_arc_001_target = v;
            aod_w_0_arc_001_draw(v, 1, 1);
          }
          const aod_w_1_date_day_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 196, y: 364, w: 80, h: 40, text_size: 40, color: 0xf50000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "" });
          const aod_w_2_date_month_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 129, y: 400, w: 220, h: 40, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "" });
          const aod_w_3_weekday_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 131, y: 326, w: 210, h: 30, text_size: 24, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "" });
          const aod_w_4_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 100, y: 175, w: 300, h: 130, text_size: 135, color: 0xfe7c02, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_e6ecf203f3be417e89e249b736c40a18_Traditionellsans_normal.ttf", text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_1_date_day_001.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            aod_w_2_date_month_001.setProperty(prop.MORE, { text: formatMonth(now, "MMMM", "RU") });
            aod_w_3_weekday_001.setProperty(prop.MORE, { text: formatWeekday(now, "EEEE", "RU") });
            aod_w_4_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
          function _tickSensorsAod() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              aod_w_0_arc_001_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { aod_w_0_arc_001_set(0); }
          }
          _tickSensorsAod();
          self._sensorTimerAod = setInterval(_tickSensorsAod, 5000);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
