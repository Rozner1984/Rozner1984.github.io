import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time, Battery, Step, Calorie, Distance, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval, setTimeout, clearTimeout } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _distance = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    const __afProfileWidgets = { day: [], night: [] };
    const __afProfileWidgetState = new Map();
    let __afActiveProfile = '';
    function __afCreateProfileWidget(profile, id, options) {
      const w = createWidget(id, options);
      const record = { widget: w, profile: profile, visible: true };
      __afProfileWidgetState.set(w, record);
      __afProfileWidgets[profile].push(record);
      try { w.setProperty(prop.VISIBLE, profile === __afActiveProfile); } catch (e) {}
      return w;
    }
    function __afCreateDayWidget(id, options) { return __afCreateProfileWidget('day', id, options); }
    function __afCreateNightWidget(id, options) { return __afCreateProfileWidget('night', id, options); }
    function __afSetProfileVisible(w, visible) {
      const record = __afProfileWidgetState.get(w);
      if (!record) { try { w.setProperty(prop.VISIBLE, !!visible); } catch (e) {} return; }
      record.visible = !!visible;
      try { w.setProperty(prop.VISIBLE, record.visible && record.profile === __afActiveProfile); } catch (e) {}
    }
    function __afProfileApply(profile) {
      profile = profile === 'night' ? 'night' : 'day';
      if (profile === __afActiveProfile) return;
      try { const offs = self._flashOffs || []; for (let i = 0; i < offs.length; i++) { try { offs[i](); } catch (e) {} } } catch (e) {}
      __afActiveProfile = profile;
      ['day', 'night'].forEach(function (key) {
        const list = __afProfileWidgets[key] || [];
        for (let i = 0; i < list.length; i++) {
          const record = list[i];
          try { record.widget.setProperty(prop.VISIBLE, record.visible && key === profile); } catch (e) {}
        }
      });
    }
    let __afProfileTime = null;
    try { __afProfileTime = new Time(); } catch (e) {}
    function __afProfileRefresh() {
      const mode = __afProfilePrefs.profileMode || 'day';
      let target = mode === 'night' ? 'night' : 'day';
      if (mode === 'auto') {
        const now = __afProfileTime ? new Date(__afProfileTime.getTime()) : new Date();
        const hour = now.getHours();
        const start = Number(__afProfilePrefs.profileStart);
        const end = Number(__afProfilePrefs.profileEnd);
        const night = start !== end && (start < end ? hour >= start && hour < end : hour >= start || hour < end);
        target = night ? 'night' : 'day';
      }
      __afProfileApply(target);
      try { if (typeof __afPanelRefresh === 'function') __afPanelRefresh(); } catch (e) {}
    }
    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bg6.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_arc_002_track = __afCreateDayWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 2, y: -45, w: 476, h: 571, start_angle: 138, end_angle: 42, color: 0xc6494b, line_width: 4, corner_flag: 1 });
          const normal_w_0_arc_002 = __afCreateDayWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 2, y: -45, w: 476, h: 571, start_angle: 138, end_angle: 138, color: 0x07e451, line_width: 4, corner_flag: 1 });
          // Дуга normal_w_0_arc_002: значение из источника BATTERY, углы на часах 138°…42° (0° = 3 часа)
          let normal_w_0_arc_002_target = 0, normal_w_0_arc_002_phase = 2, normal_w_0_arc_002_timer = null, normal_w_0_arc_002_err = false;
          function normal_w_0_arc_002_draw(r, f, g) {
            try {
              normal_w_0_arc_002.setProperty(prop.MORE, { x: 2, y: -45, w: 476, h: 571, start_angle: 138, end_angle: Math.round(138 + (-96) * r), color: 0x07e451, line_width: 4 });
            } catch (e) { if (!normal_w_0_arc_002_err) { normal_w_0_arc_002_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_0_arc_002_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_0_arc_002_target = v;
            normal_w_0_arc_002_draw(v, 1, 1);
          }
          const normal_w_1_weather_icon_001 = __afCreateDayWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 10, y: 206, w: 64, h: 64, image_array: ["weather/64x64/0_cloudy.png", "weather/64x64/1_showers.png", "weather/64x64/2_snow_showers.png", "weather/64x64/3_sunny.png", "weather/64x64/4_overcast.png", "weather/64x64/5_light_rain.png", "weather/64x64/6_light_snow.png", "weather/64x64/7_moderate_rain.png", "weather/64x64/8_moderate_snow.png", "weather/64x64/9_heavy_snow.png", "weather/64x64/10_heavy_rain.png", "weather/64x64/11_sandstorm.png", "weather/64x64/12_rain_snow.png", "weather/64x64/13_fog.png", "weather/64x64/14_hazy.png", "weather/64x64/15_thunderstorm.png", "weather/64x64/16_snowstorm.png", "weather/64x64/17_floating_dust.png", "weather/64x64/18_very_heavy_rainstorm.png", "weather/64x64/19_rain_hail.png", "weather/64x64/20_thunderstorm_hail.png", "weather/64x64/21_heavy_rainstorm.png", "weather/64x64/22_dust.png", "weather/64x64/23_heavy_sandstorm.png", "weather/64x64/24_rainstorm.png", "weather/64x64/25_unknown.png", "weather/64x64/26_cloudy_night.png", "weather/64x64/27_showers_night.png", "weather/64x64/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 14, alpha: 255 });
          const normal_w_2_battery_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 312, y: 68, w: 100, h: 36, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_3_steps_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 60, y: 69, w: 150, h: 36, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_4_calories_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 70, y: 380, w: 120, h: 32, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afCreateDayWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 46, y: 223, w: 120, h: 40, text_size: 32, color: 0xeb0000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 0 });
          const normal_w_6_date_full_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 320, w: 220, h: 40, text_size: 40, color: 0xf00000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_7_heart_rate_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 200, y: 98, w: 100, h: 36, text_size: 30, color: 0xef9922, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_8_distance_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 300, y: 378, w: 120, h: 32, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _distance = new Distance(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_6_date_full_001.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_0_arc_002_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { normal_w_0_arc_002_set(0); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_2_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_2_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_3_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_4_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_4_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_7_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_7_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const raw = _distance ? _distance.getCurrent() : null;
              // Единица возвращаемого значения в документации не указана (⚠) — принята за метры.
              let v = typeof raw === 'number' ? raw / 1000 : null;
              const txt = v !== null ? v.toFixed(2) : '--';
              normal_w_8_distance_001.setProperty(prop.MORE, { text: "" + txt + " km" });
            } catch (e) { normal_w_8_distance_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // Night profile widgets — isolated lexical scope
    {
          const __bgColor_night_ = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_night_.setAlpha(255);
          const __bgImage_night_ = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bg6.png" });
          __bgImage_night_.setAlpha(255);
          const night_w_0_arc_002_track = __afCreateNightWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 2, y: -45, w: 476, h: 571, start_angle: 138, end_angle: 42, color: 0xc6494b, line_width: 4, corner_flag: 1 });
          const night_w_0_arc_002 = __afCreateNightWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 2, y: -45, w: 476, h: 571, start_angle: 138, end_angle: 138, color: 0x07e451, line_width: 4, corner_flag: 1 });
          // Дуга night_w_0_arc_002: значение из источника BATTERY, углы на часах 138°…42° (0° = 3 часа)
          let night_w_0_arc_002_target = 0, night_w_0_arc_002_phase = 2, night_w_0_arc_002_timer = null, night_w_0_arc_002_err = false;
          function night_w_0_arc_002_draw(r, f, g) {
            try {
              night_w_0_arc_002.setProperty(prop.MORE, { x: 2, y: -45, w: 476, h: 571, start_angle: 138, end_angle: Math.round(138 + (-96) * r), color: 0x07e451, line_width: 4 });
            } catch (e) { if (!night_w_0_arc_002_err) { night_w_0_arc_002_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function night_w_0_arc_002_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            night_w_0_arc_002_target = v;
            night_w_0_arc_002_draw(v, 1, 1);
          }
          const night_w_1_weather_icon_001 = __afCreateNightWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 10, y: 206, w: 64, h: 64, image_array: ["weather/64x64/0_cloudy.png", "weather/64x64/1_showers.png", "weather/64x64/2_snow_showers.png", "weather/64x64/3_sunny.png", "weather/64x64/4_overcast.png", "weather/64x64/5_light_rain.png", "weather/64x64/6_light_snow.png", "weather/64x64/7_moderate_rain.png", "weather/64x64/8_moderate_snow.png", "weather/64x64/9_heavy_snow.png", "weather/64x64/10_heavy_rain.png", "weather/64x64/11_sandstorm.png", "weather/64x64/12_rain_snow.png", "weather/64x64/13_fog.png", "weather/64x64/14_hazy.png", "weather/64x64/15_thunderstorm.png", "weather/64x64/16_snowstorm.png", "weather/64x64/17_floating_dust.png", "weather/64x64/18_very_heavy_rainstorm.png", "weather/64x64/19_rain_hail.png", "weather/64x64/20_thunderstorm_hail.png", "weather/64x64/21_heavy_rainstorm.png", "weather/64x64/22_dust.png", "weather/64x64/23_heavy_sandstorm.png", "weather/64x64/24_rainstorm.png", "weather/64x64/25_unknown.png", "weather/64x64/26_cloudy_night.png", "weather/64x64/27_showers_night.png", "weather/64x64/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 14, alpha: 255 });
          const night_w_2_battery_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 312, y: 68, w: 100, h: 36, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const night_w_3_steps_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 60, y: 69, w: 150, h: 36, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const night_w_4_calories_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 70, y: 380, w: 120, h: 32, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afCreateNightWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 46, y: 223, w: 120, h: 40, text_size: 32, color: 0xeb0000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 0 });
          const night_w_6_date_full_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 320, w: 220, h: 40, text_size: 40, color: 0xf00000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const night_w_7_heart_rate_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 200, y: 98, w: 100, h: 36, text_size: 30, color: 0xef9922, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const night_w_8_distance_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 300, y: 378, w: 120, h: 32, text_size: 32, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _distance = new Distance(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNight() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            night_w_6_date_full_001.setProperty(prop.MORE, { text: formatDate(now, "DD MMM", "RU") });
          }
          _tickNight();
          self._timeTimerNight = setInterval(_tickNight, 1000);
      
          function _tickSensorsNight() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              night_w_0_arc_002_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { night_w_0_arc_002_set(0); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              night_w_2_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { night_w_2_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              night_w_3_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_3_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              night_w_4_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_4_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              night_w_7_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_7_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const raw = _distance ? _distance.getCurrent() : null;
              // Единица возвращаемого значения в документации не указана (⚠) — принята за метры.
              let v = typeof raw === 'number' ? raw / 1000 : null;
              const txt = v !== null ? v.toFixed(2) : '--';
              night_w_8_distance_001.setProperty(prop.MORE, { text: "" + txt + " km" });
            } catch (e) { night_w_8_distance_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNight();
          self._sensorTimerNight = setInterval(_tickSensorsNight, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
      
    }
    const __afProfilePrefs = { profileMode: "auto", profileStart: 22, profileEnd: 7 };
    __afProfileRefresh();
    self._dayNightTimer = setInterval(__afProfileRefresh, 30000);
    try { createWidget(widget.WIDGET_DELEGATE, { resume_call: function () { try { __afProfileRefresh(); } catch (e) {} } }); } catch (e) {}
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._timeTimerNight) { clearInterval(this._timeTimerNight); this._timeTimerNight = null; }
    if (this._sensorTimerNight) { clearInterval(this._sensorTimerNight); this._sensorTimerNight = null; }
    if (this._smoothTimerNight) { clearInterval(this._smoothTimerNight); this._smoothTimerNight = null; }
    if (this._dayNightTimer) { clearInterval(this._dayNightTimer); this._dayNightTimer = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
