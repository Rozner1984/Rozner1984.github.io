import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Battery, Screen } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _battery = null;

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bg6.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_arc_001 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 4, w: 481, h: 470, start_angle: 136, end_angle: 136, color: 0x06c144, line_width: 4, corner_flag: 1 });
          // Дуга normal_w_0_arc_001: значение из источника BATTERY, углы на часах 136°…4° (0° = 3 часа)
          let normal_w_0_arc_001_target = 0, normal_w_0_arc_001_phase = 0, normal_w_0_arc_001_timer = null, normal_w_0_arc_001_err = false;
          function normal_w_0_arc_001_draw(r, f, g) {
            try {
              normal_w_0_arc_001.setProperty(prop.MORE, { x: 0, y: 4, w: 481, h: 470, start_angle: 136, end_angle: Math.round(136 + (-132) * r), color: 0x06c144, line_width: 4 });
            } catch (e) { if (!normal_w_0_arc_001_err) { normal_w_0_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_0_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_0_arc_001_target = v;
            if (normal_w_0_arc_001_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_0_arc_001_phase === 0) { normal_w_0_arc_001_phase = 1; normal_w_0_arc_001_run(); return; }
            normal_w_0_arc_001_draw(v, 1, 1);
          }
          function normal_w_0_arc_001_run() {
            let n = 0;
            normal_w_0_arc_001_draw(0, 0, 0);
            normal_w_0_arc_001_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = (1 - Math.pow(1 - (k), 3));
              normal_w_0_arc_001_draw(e * normal_w_0_arc_001_target, 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_0_arc_001_timer); normal_w_0_arc_001_timer = null; normal_w_0_arc_001_phase = 2;
                normal_w_0_arc_001_draw(normal_w_0_arc_001_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_0_arc_001_replay() {
            if (normal_w_0_arc_001_phase !== 2) return;
            normal_w_0_arc_001_phase = 1;
            normal_w_0_arc_001_run();
          }
      
          // Повтор анимации дуг при поднятии руки (Screen.onChange + страховка по паузе таймера)
          try {
            const _scr = new Screen();
            let _scrPrev = 1;
            try { _scrPrev = _scr.getStatus(); } catch (e) {}
            const _raise = function (why) {
              try { console.log('arc replay: ' + why); } catch (e) {}
              try { normal_w_0_arc_001_replay(); } catch (e) {}
            };
            self._screen = _scr;
            self._screenCb = function (st) {
              try {
                const cur = (typeof st === 'number') ? st : _scr.getStatus();
                try { console.log('screen status: ' + cur); } catch (e) {}
                const was = _scrPrev; _scrPrev = cur;
                if (cur === 1 && was !== 1) _raise('screen on');
              } catch (e) {}
            };
            _scr.onChange(self._screenCb);
            let _hbLast = Date.now();
            self._raiseTimer = setInterval(function () {
              try {
                const t = Date.now();
                if (t - _hbLast > 3000) _raise('timer gap ' + (t - _hbLast) + ' ms');
                _hbLast = t;
              } catch (e) {}
            }, 1000);
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _battery = new Battery(); } catch (e) {}
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_0_arc_001_set(typeof v === 'number' ? (v - 1) / 99 : 0);
            } catch (e) { normal_w_0_arc_001_set(0); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
