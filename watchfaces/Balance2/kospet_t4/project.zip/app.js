App({
  globalData: {},
})
