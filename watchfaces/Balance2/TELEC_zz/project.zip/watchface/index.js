import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time, Battery, Step, Calorie, HeartRate, Screen } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "fon_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 195, y: 14, w: 100, h: 36, text_size: 26, color: 0x5ab0e6, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_5942d0a0d63c4e3d9c5d3f50417589df_Whoosit.ttf", text: "--" });
          const normal_w_1_heart_rate_002 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 10, y: 219, w: 100, h: 42, text_size: 35, color: 0x5ab0e6, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_5942d0a0d63c4e3d9c5d3f50417589df_Whoosit.ttf", text: "--" });
          const normal_w_2_date_full_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 133, y: 107, w: 220, h: 44, text_size: 36, color: 0x5ab0e6, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_5942d0a0d63c4e3d9c5d3f50417589df_Whoosit.ttf", text: "" });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 366, y: 210, w: 120, h: 45, text_size: 36, color: 0x5ab0e6, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_5942d0a0d63c4e3d9c5d3f50417589df_Whoosit.ttf", type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_w_4_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 275, y: 350, w: 120, h: 42, text_size: 30, color: 0x5ab0e6, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_5942d0a0d63c4e3d9c5d3f50417589df_Whoosit.ttf", text: "--" });
          const normal_w_5_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 73, y: 350, w: 150, h: 36, text_size: 30, color: 0x5ab0e6, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_5942d0a0d63c4e3d9c5d3f50417589df_Whoosit.ttf", text: "--" });
          const normal_w_6_arc_001_a = [-83, -69, -54, -40, -25, -11, 4, 18, 32, 47, 61, 76, 90, 104, 119, 133, 148, 162, 177, 191, 205, 220, 234, 249], normal_w_6_arc_001_b = [-70, -55, -41, -26, -12, 2, 17, 31, 46, 60, 75, 89, 103, 118, 132, 147, 161, 175, 190, 204, 219, 233, 248, 262], normal_w_6_arc_001_c = [0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6, 0x5ab0e6];
          const normal_w_6_arc_001_segs = [], normal_w_6_arc_001_vis = [];
          for (let normal_w_6_arc_001_i = 0; normal_w_6_arc_001_i < 24; normal_w_6_arc_001_i++) {
            normal_w_6_arc_001_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, start_angle: normal_w_6_arc_001_b[normal_w_6_arc_001_i], end_angle: normal_w_6_arc_001_b[normal_w_6_arc_001_i], color: normal_w_6_arc_001_c[normal_w_6_arc_001_i], line_width: 9 }));
            normal_w_6_arc_001_vis[normal_w_6_arc_001_i] = false;
            if (!normal_w_6_arc_001_vis[normal_w_6_arc_001_i]) normal_w_6_arc_001_segs[normal_w_6_arc_001_i].setProperty(prop.VISIBLE, false);
          }
          // Дуга normal_w_6_arc_001: значение из источника BATTERY, углы на часах -83°…262° (0° = 3 часа)
          let normal_w_6_arc_001_target = 0, normal_w_6_arc_001_phase = 2, normal_w_6_arc_001_timer = null, normal_w_6_arc_001_err = false;
          const normal_w_6_arc_001_last = [];
          function normal_w_6_arc_001_draw(r, f, g) {
            try {
              const cur = 262 + (-345) * r;
              const lw = 9;
              for (let normal_w_6_arc_001_k = 0; normal_w_6_arc_001_k < 24; normal_w_6_arc_001_k++) {
                const a = normal_w_6_arc_001_a[normal_w_6_arc_001_k], b = normal_w_6_arc_001_b[normal_w_6_arc_001_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));   // граница заполнения внутри сегмента
                const col = normal_w_6_arc_001_c[normal_w_6_arc_001_k];
                const key = end + ':' + col + ':' + lw;
                if (normal_w_6_arc_001_last[normal_w_6_arc_001_k] === key) continue;
                normal_w_6_arc_001_last[normal_w_6_arc_001_k] = key;
                if (end === b) { if (normal_w_6_arc_001_vis[normal_w_6_arc_001_k]) { normal_w_6_arc_001_vis[normal_w_6_arc_001_k] = false; normal_w_6_arc_001_segs[normal_w_6_arc_001_k].setProperty(prop.VISIBLE, false); } continue; }
                normal_w_6_arc_001_segs[normal_w_6_arc_001_k].setProperty(prop.MORE, { x: 0, y: 0, w: 480, h: 480, start_angle: end, end_angle: b, color: col, line_width: lw });
                if (!normal_w_6_arc_001_vis[normal_w_6_arc_001_k]) { normal_w_6_arc_001_vis[normal_w_6_arc_001_k] = true; normal_w_6_arc_001_segs[normal_w_6_arc_001_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_6_arc_001_err) { normal_w_6_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_6_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_6_arc_001_target = v;
            normal_w_6_arc_001_draw(v, 1, 1);
          }
          const normal_w_7_arc_002_a = [-260, -246, -232, -217, -203, -189, -175, -161, -147, -132, -118, -104, -90, -76, -62, -47, -33, -19, -5, 9, 23, 38, 52, 66], normal_w_7_arc_002_b = [-245, -231, -216, -202, -188, -174, -160, -146, -132, -117, -103, -89, -75, -61, -47, -32, -18, -4, 10, 24, 38, 53, 67, 80], normal_w_7_arc_002_c = [0xf38ca0, 0xf2899e, 0xf1879b, 0xef8499, 0xee8197, 0xed7f94, 0xec7c92, 0xeb7990, 0xea778e, 0xe8748b, 0xe77189, 0xe66f87, 0xe56c84, 0xe46a82, 0xe36780, 0xe1647d, 0xe0627b, 0xdf5f79, 0xde5c77, 0xdd5a74, 0xdc5772, 0xda5470, 0xd9526d, 0xd84f6b];
          const normal_w_7_arc_002_segs = [], normal_w_7_arc_002_vis = [];
          for (let normal_w_7_arc_002_i = 0; normal_w_7_arc_002_i < 24; normal_w_7_arc_002_i++) {
            normal_w_7_arc_002_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 15, y: 193, w: 93, h: 95, start_angle: normal_w_7_arc_002_a[normal_w_7_arc_002_i], end_angle: normal_w_7_arc_002_a[normal_w_7_arc_002_i], color: normal_w_7_arc_002_c[normal_w_7_arc_002_i], line_width: 5 }));
            normal_w_7_arc_002_vis[normal_w_7_arc_002_i] = false;
            if (!normal_w_7_arc_002_vis[normal_w_7_arc_002_i]) normal_w_7_arc_002_segs[normal_w_7_arc_002_i].setProperty(prop.VISIBLE, false);
          }
          // Дуга normal_w_7_arc_002: значение из источника HEART, углы на часах -260°…80° (0° = 3 часа)
          let normal_w_7_arc_002_target = 0, normal_w_7_arc_002_phase = 0, normal_w_7_arc_002_timer = null, normal_w_7_arc_002_err = false;
          const normal_w_7_arc_002_last = [];
          function normal_w_7_arc_002_draw(r, f, g) {
            try {
              const cur = -260 + (340) * r;
              const lw = 5;
              for (let normal_w_7_arc_002_k = 0; normal_w_7_arc_002_k < 24; normal_w_7_arc_002_k++) {
                const a = normal_w_7_arc_002_a[normal_w_7_arc_002_k], b = normal_w_7_arc_002_b[normal_w_7_arc_002_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));   // граница заполнения внутри сегмента
                const col = normal_w_7_arc_002_c[normal_w_7_arc_002_k];
                const key = end + ':' + col + ':' + lw;
                if (normal_w_7_arc_002_last[normal_w_7_arc_002_k] === key) continue;
                normal_w_7_arc_002_last[normal_w_7_arc_002_k] = key;
                if (end === a) { if (normal_w_7_arc_002_vis[normal_w_7_arc_002_k]) { normal_w_7_arc_002_vis[normal_w_7_arc_002_k] = false; normal_w_7_arc_002_segs[normal_w_7_arc_002_k].setProperty(prop.VISIBLE, false); } continue; }
                normal_w_7_arc_002_segs[normal_w_7_arc_002_k].setProperty(prop.MORE, { x: 15, y: 193, w: 93, h: 95, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!normal_w_7_arc_002_vis[normal_w_7_arc_002_k]) { normal_w_7_arc_002_vis[normal_w_7_arc_002_k] = true; normal_w_7_arc_002_segs[normal_w_7_arc_002_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_7_arc_002_err) { normal_w_7_arc_002_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_7_arc_002_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_7_arc_002_target = v;
            if (normal_w_7_arc_002_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_7_arc_002_phase === 0) { normal_w_7_arc_002_phase = 1; normal_w_7_arc_002_run(); return; }
            normal_w_7_arc_002_draw(v, 1, 1);
          }
          function normal_w_7_arc_002_run() {
            let n = 0;
            normal_w_7_arc_002_draw(0, 0, 0);
            normal_w_7_arc_002_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = (1 - Math.pow(1 - (k), 3));
              normal_w_7_arc_002_draw(e * normal_w_7_arc_002_target, 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_7_arc_002_timer); normal_w_7_arc_002_timer = null; normal_w_7_arc_002_phase = 2;
                normal_w_7_arc_002_draw(normal_w_7_arc_002_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_7_arc_002_replay() {
            if (normal_w_7_arc_002_phase !== 2) return;
            normal_w_7_arc_002_phase = 1;
            normal_w_7_arc_002_run();
          }
          const normal_w_8_arc_003_a = [-260, -246, -232, -217, -203, -189, -175, -161, -147, -132, -118, -104, -90, -76, -62, -47, -33, -19, -5, 9, 23, 38, 52, 66], normal_w_8_arc_003_b = [-245, -231, -216, -202, -188, -174, -160, -146, -132, -117, -103, -89, -75, -61, -47, -32, -18, -4, 10, 24, 38, 53, 67, 80], normal_w_8_arc_003_c = [0xf38ca0, 0xf2899e, 0xf1879b, 0xef8499, 0xee8197, 0xed7f94, 0xec7c92, 0xeb7990, 0xea778e, 0xe8748b, 0xe77189, 0xe66f87, 0xe56c84, 0xe46a82, 0xe36780, 0xe1647d, 0xe0627b, 0xdf5f79, 0xde5c77, 0xdd5a74, 0xdc5772, 0xda5470, 0xd9526d, 0xd84f6b];
          const normal_w_8_arc_003_segs = [], normal_w_8_arc_003_vis = [];
          for (let normal_w_8_arc_003_i = 0; normal_w_8_arc_003_i < 24; normal_w_8_arc_003_i++) {
            normal_w_8_arc_003_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 370, y: 193, w: 93, h: 95, start_angle: normal_w_8_arc_003_a[normal_w_8_arc_003_i], end_angle: normal_w_8_arc_003_a[normal_w_8_arc_003_i], color: normal_w_8_arc_003_c[normal_w_8_arc_003_i], line_width: 5 }));
            normal_w_8_arc_003_vis[normal_w_8_arc_003_i] = false;
            if (!normal_w_8_arc_003_vis[normal_w_8_arc_003_i]) normal_w_8_arc_003_segs[normal_w_8_arc_003_i].setProperty(prop.VISIBLE, false);
          }
          // Дуга normal_w_8_arc_003: статическая, углы на часах -260°…80° (0° = 3 часа)
          let normal_w_8_arc_003_target = 1, normal_w_8_arc_003_phase = 0, normal_w_8_arc_003_timer = null, normal_w_8_arc_003_err = false;
          const normal_w_8_arc_003_last = [];
          function normal_w_8_arc_003_draw(r, f, g) {
            try {
              const cur = -260 + (340) * r;
              const lw = 5;
              for (let normal_w_8_arc_003_k = 0; normal_w_8_arc_003_k < 24; normal_w_8_arc_003_k++) {
                const a = normal_w_8_arc_003_a[normal_w_8_arc_003_k], b = normal_w_8_arc_003_b[normal_w_8_arc_003_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));   // граница заполнения внутри сегмента
                const col = normal_w_8_arc_003_c[normal_w_8_arc_003_k];
                const key = end + ':' + col + ':' + lw;
                if (normal_w_8_arc_003_last[normal_w_8_arc_003_k] === key) continue;
                normal_w_8_arc_003_last[normal_w_8_arc_003_k] = key;
                if (end === a) { if (normal_w_8_arc_003_vis[normal_w_8_arc_003_k]) { normal_w_8_arc_003_vis[normal_w_8_arc_003_k] = false; normal_w_8_arc_003_segs[normal_w_8_arc_003_k].setProperty(prop.VISIBLE, false); } continue; }
                normal_w_8_arc_003_segs[normal_w_8_arc_003_k].setProperty(prop.MORE, { x: 370, y: 193, w: 93, h: 95, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!normal_w_8_arc_003_vis[normal_w_8_arc_003_k]) { normal_w_8_arc_003_vis[normal_w_8_arc_003_k] = true; normal_w_8_arc_003_segs[normal_w_8_arc_003_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_8_arc_003_err) { normal_w_8_arc_003_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_8_arc_003_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_8_arc_003_target = v;
            if (normal_w_8_arc_003_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_8_arc_003_phase === 0) { normal_w_8_arc_003_phase = 1; normal_w_8_arc_003_run(); return; }
            normal_w_8_arc_003_draw(v, 1, 1);
          }
          function normal_w_8_arc_003_run() {
            let n = 0;
            normal_w_8_arc_003_draw(0, 0, 0);
            normal_w_8_arc_003_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = (1 - Math.pow(1 - (k), 3));
              normal_w_8_arc_003_draw(e * normal_w_8_arc_003_target, 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_8_arc_003_timer); normal_w_8_arc_003_timer = null; normal_w_8_arc_003_phase = 2;
                normal_w_8_arc_003_draw(normal_w_8_arc_003_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_8_arc_003_replay() {
            if (normal_w_8_arc_003_phase !== 2) return;
            normal_w_8_arc_003_phase = 1;
            normal_w_8_arc_003_run();
          }
          normal_w_8_arc_003_set(1);
          const normal_w_9_arc_004_a = [-260, -246, -232, -217, -203, -189, -175, -161, -147, -132, -118, -104, -90, -76, -62, -47, -33, -19, -5, 9, 23, 38, 52, 66], normal_w_9_arc_004_b = [-245, -231, -216, -202, -188, -174, -160, -146, -132, -117, -103, -89, -75, -61, -47, -32, -18, -4, 10, 24, 38, 53, 67, 80], normal_w_9_arc_004_c = [0xf38ca0, 0xf2899e, 0xf1879b, 0xef8499, 0xee8197, 0xed7f94, 0xec7c92, 0xeb7990, 0xea778e, 0xe8748b, 0xe77189, 0xe66f87, 0xe56c84, 0xe46a82, 0xe36780, 0xe1647d, 0xe0627b, 0xdf5f79, 0xde5c77, 0xdd5a74, 0xdc5772, 0xda5470, 0xd9526d, 0xd84f6b];
          const normal_w_9_arc_004_segs = [], normal_w_9_arc_004_vis = [];
          for (let normal_w_9_arc_004_i = 0; normal_w_9_arc_004_i < 24; normal_w_9_arc_004_i++) {
            normal_w_9_arc_004_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 99, y: 322, w: 95, h: 94, start_angle: normal_w_9_arc_004_a[normal_w_9_arc_004_i], end_angle: normal_w_9_arc_004_a[normal_w_9_arc_004_i], color: normal_w_9_arc_004_c[normal_w_9_arc_004_i], line_width: 5 }));
            normal_w_9_arc_004_vis[normal_w_9_arc_004_i] = false;
            if (!normal_w_9_arc_004_vis[normal_w_9_arc_004_i]) normal_w_9_arc_004_segs[normal_w_9_arc_004_i].setProperty(prop.VISIBLE, false);
          }
          // Дуга normal_w_9_arc_004: значение из источника STEP, углы на часах -260°…80° (0° = 3 часа)
          let normal_w_9_arc_004_target = 0, normal_w_9_arc_004_phase = 0, normal_w_9_arc_004_timer = null, normal_w_9_arc_004_err = false;
          const normal_w_9_arc_004_last = [];
          function normal_w_9_arc_004_draw(r, f, g) {
            try {
              const cur = -260 + (340) * r;
              const lw = 5;
              for (let normal_w_9_arc_004_k = 0; normal_w_9_arc_004_k < 24; normal_w_9_arc_004_k++) {
                const a = normal_w_9_arc_004_a[normal_w_9_arc_004_k], b = normal_w_9_arc_004_b[normal_w_9_arc_004_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));   // граница заполнения внутри сегмента
                const col = normal_w_9_arc_004_c[normal_w_9_arc_004_k];
                const key = end + ':' + col + ':' + lw;
                if (normal_w_9_arc_004_last[normal_w_9_arc_004_k] === key) continue;
                normal_w_9_arc_004_last[normal_w_9_arc_004_k] = key;
                if (end === a) { if (normal_w_9_arc_004_vis[normal_w_9_arc_004_k]) { normal_w_9_arc_004_vis[normal_w_9_arc_004_k] = false; normal_w_9_arc_004_segs[normal_w_9_arc_004_k].setProperty(prop.VISIBLE, false); } continue; }
                normal_w_9_arc_004_segs[normal_w_9_arc_004_k].setProperty(prop.MORE, { x: 99, y: 322, w: 95, h: 94, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!normal_w_9_arc_004_vis[normal_w_9_arc_004_k]) { normal_w_9_arc_004_vis[normal_w_9_arc_004_k] = true; normal_w_9_arc_004_segs[normal_w_9_arc_004_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_9_arc_004_err) { normal_w_9_arc_004_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_9_arc_004_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_9_arc_004_target = v;
            if (normal_w_9_arc_004_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_9_arc_004_phase === 0) { normal_w_9_arc_004_phase = 1; normal_w_9_arc_004_run(); return; }
            normal_w_9_arc_004_draw(v, 1, 1);
          }
          function normal_w_9_arc_004_run() {
            let n = 0;
            normal_w_9_arc_004_draw(0, 0, 0);
            normal_w_9_arc_004_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = (1 - Math.pow(1 - (k), 3));
              normal_w_9_arc_004_draw(e * normal_w_9_arc_004_target, 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_9_arc_004_timer); normal_w_9_arc_004_timer = null; normal_w_9_arc_004_phase = 2;
                normal_w_9_arc_004_draw(normal_w_9_arc_004_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_9_arc_004_replay() {
            if (normal_w_9_arc_004_phase !== 2) return;
            normal_w_9_arc_004_phase = 1;
            normal_w_9_arc_004_run();
          }
          const normal_w_10_arc_005_a = [-260, -246, -232, -217, -203, -189, -175, -161, -147, -132, -118, -104, -90, -76, -62, -47, -33, -19, -5, 9, 23, 38, 52, 66], normal_w_10_arc_005_b = [-245, -231, -216, -202, -188, -174, -160, -146, -132, -117, -103, -89, -75, -61, -47, -32, -18, -4, 10, 24, 38, 53, 67, 80], normal_w_10_arc_005_c = [0xf38ca0, 0xf2899e, 0xf1879b, 0xef8499, 0xee8197, 0xed7f94, 0xec7c92, 0xeb7990, 0xea778e, 0xe8748b, 0xe77189, 0xe66f87, 0xe56c84, 0xe46a82, 0xe36780, 0xe1647d, 0xe0627b, 0xdf5f79, 0xde5c77, 0xdd5a74, 0xdc5772, 0xda5470, 0xd9526d, 0xd84f6b];
          const normal_w_10_arc_005_segs = [], normal_w_10_arc_005_vis = [];
          for (let normal_w_10_arc_005_i = 0; normal_w_10_arc_005_i < 24; normal_w_10_arc_005_i++) {
            normal_w_10_arc_005_segs.push(createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 285, y: 322, w: 95, h: 94, start_angle: normal_w_10_arc_005_a[normal_w_10_arc_005_i], end_angle: normal_w_10_arc_005_a[normal_w_10_arc_005_i], color: normal_w_10_arc_005_c[normal_w_10_arc_005_i], line_width: 5 }));
            normal_w_10_arc_005_vis[normal_w_10_arc_005_i] = false;
            if (!normal_w_10_arc_005_vis[normal_w_10_arc_005_i]) normal_w_10_arc_005_segs[normal_w_10_arc_005_i].setProperty(prop.VISIBLE, false);
          }
          // Дуга normal_w_10_arc_005: значение из источника CALORIE, углы на часах -260°…80° (0° = 3 часа)
          let normal_w_10_arc_005_target = 0, normal_w_10_arc_005_phase = 0, normal_w_10_arc_005_timer = null, normal_w_10_arc_005_err = false;
          const normal_w_10_arc_005_last = [];
          function normal_w_10_arc_005_draw(r, f, g) {
            try {
              const cur = -260 + (340) * r;
              const lw = 5;
              for (let normal_w_10_arc_005_k = 0; normal_w_10_arc_005_k < 24; normal_w_10_arc_005_k++) {
                const a = normal_w_10_arc_005_a[normal_w_10_arc_005_k], b = normal_w_10_arc_005_b[normal_w_10_arc_005_k];
                const end = Math.round(Math.max(a, Math.min(b, cur)));   // граница заполнения внутри сегмента
                const col = normal_w_10_arc_005_c[normal_w_10_arc_005_k];
                const key = end + ':' + col + ':' + lw;
                if (normal_w_10_arc_005_last[normal_w_10_arc_005_k] === key) continue;
                normal_w_10_arc_005_last[normal_w_10_arc_005_k] = key;
                if (end === a) { if (normal_w_10_arc_005_vis[normal_w_10_arc_005_k]) { normal_w_10_arc_005_vis[normal_w_10_arc_005_k] = false; normal_w_10_arc_005_segs[normal_w_10_arc_005_k].setProperty(prop.VISIBLE, false); } continue; }
                normal_w_10_arc_005_segs[normal_w_10_arc_005_k].setProperty(prop.MORE, { x: 285, y: 322, w: 95, h: 94, start_angle: a, end_angle: end, color: col, line_width: lw });
                if (!normal_w_10_arc_005_vis[normal_w_10_arc_005_k]) { normal_w_10_arc_005_vis[normal_w_10_arc_005_k] = true; normal_w_10_arc_005_segs[normal_w_10_arc_005_k].setProperty(prop.VISIBLE, true); }
              }
            } catch (e) { if (!normal_w_10_arc_005_err) { normal_w_10_arc_005_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_10_arc_005_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_10_arc_005_target = v;
            if (normal_w_10_arc_005_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_10_arc_005_phase === 0) { normal_w_10_arc_005_phase = 1; normal_w_10_arc_005_run(); return; }
            normal_w_10_arc_005_draw(v, 1, 1);
          }
          function normal_w_10_arc_005_run() {
            let n = 0;
            normal_w_10_arc_005_draw(0, 0, 0);
            normal_w_10_arc_005_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = (1 - Math.pow(1 - (k), 3));
              normal_w_10_arc_005_draw(e * normal_w_10_arc_005_target, 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_10_arc_005_timer); normal_w_10_arc_005_timer = null; normal_w_10_arc_005_phase = 2;
                normal_w_10_arc_005_draw(normal_w_10_arc_005_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_10_arc_005_replay() {
            if (normal_w_10_arc_005_phase !== 2) return;
            normal_w_10_arc_005_phase = 1;
            normal_w_10_arc_005_run();
          }
          const normal_w_11_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 160, w: 300, h: 131, text_size: 106, color: 0xd97b8e, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_5942d0a0d63c4e3d9c5d3f50417589df_Whoosit.ttf", text: "" });
          const normal_w_12_time_second_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 190, y: 260, w: 100, h: 83, text_size: 69, color: 0x5ab0e6, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_5942d0a0d63c4e3d9c5d3f50417589df_Whoosit.ttf", text: "" });
      
          // Повтор анимации дуг при возврате на циферблат / пробуждении экрана
          try {
            createWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { console.log('watchface resume'); } catch (e) {}
                try { normal_w_7_arc_002_replay(); } catch (e) {}
                try { normal_w_8_arc_003_replay(); } catch (e) {}
                try { normal_w_9_arc_004_replay(); } catch (e) {}
                try { normal_w_10_arc_005_replay(); } catch (e) {}
              },
              pause_call: function () {},
            });
          } catch (e) {}
      
          // Повтор анимации дуг при поднятии руки (Screen.onChange + страховка по паузе таймера)
          try {
            const _scr = new Screen();
            let _scrPrev = 1;
            try { _scrPrev = _scr.getStatus(); } catch (e) {}
            const _raise = function (why) {
              try { console.log('arc replay: ' + why); } catch (e) {}
              try { normal_w_7_arc_002_replay(); } catch (e) {}
              try { normal_w_8_arc_003_replay(); } catch (e) {}
              try { normal_w_9_arc_004_replay(); } catch (e) {}
              try { normal_w_10_arc_005_replay(); } catch (e) {}
            };
            self._screen = _scr;
            self._screenCb = function (st) {
              try {
                const cur = (typeof st === 'number') ? st : _scr.getStatus();
                try { console.log('screen status: ' + cur); } catch (e) {}
                const was = _scrPrev; _scrPrev = cur;
                if (cur === 1 && was !== 1) _raise('screen on');
              } catch (e) {}
            };
            _scr.onChange(self._screenCb);
            let _hbLast = Date.now();
            self._raiseTimer = setInterval(function () {
              try {
                const t = Date.now();
                if (t - _hbLast > 3000) _raise('timer gap ' + (t - _hbLast) + ' ms');
                _hbLast = t;
              } catch (e) {}
            }, 1000);
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_2_date_full_001.setProperty(prop.MORE, { text: formatDate(now, "DD.MM.YYYY", "EN") });
            normal_w_11_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            normal_w_12_time_second_001.setProperty(prop.MORE, { text: formatUnit(now.getSeconds(), true) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_0_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_0_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_1_heart_rate_002.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_1_heart_rate_002.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_4_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_4_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_5_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_5_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_6_arc_001_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { normal_w_6_arc_001_set(0); }
            try {
              const v = _heartVal;
              normal_w_7_arc_002_set(typeof v === 'number' ? (v - 60) / 116 : 0);
            } catch (e) { normal_w_7_arc_002_set(0); }
            try {
              const v = _step ? _step.getCurrent() : null;
              normal_w_9_arc_004_set(typeof v === 'number' ? (v - 0) / 10000 : 0);
            } catch (e) { normal_w_9_arc_004_set(0); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              normal_w_10_arc_005_set(typeof v === 'number' ? (v - 0) / 300 : 0);
            } catch (e) { normal_w_10_arc_005_set(0); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
