import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Battery, Step, Calorie } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _battery = null;
let _step = null;
let _calorie = null;

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bezymyannyy.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_image_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 195, y: 150, w: 30, h: 20, src: "akum_30x20.png" });
          normal_w_0_image_001.setAlpha(255);
          const normal_w_1_image_002 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 161, y: 270, w: 30, h: 30, src: "shagi_edited_30x30.png" });
          normal_w_1_image_002.setAlpha(255);
          const normal_w_2_image_003 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 292, y: 267, w: 30, h: 30, src: "kalorii_edited_30x30.png" });
          normal_w_2_image_003.setAlpha(255);
          const normal_w_3_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 310, w: 150, h: 36, text_size: 30, color: 0x141414, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_4_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 250, y: 310, w: 120, h: 36, text_size: 30, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          second_centerX: 250, second_centerY: 240, second_posX: 10, second_posY: 155, second_path: "shar_second_hand_second_hand_second_hand.png" });
          const normal_w_5_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 228, y: 144, w: 100, h: 36, text_size: 26, color: 0x121212, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 34, hour_posY: 104, hour_path: "hh_hour_hand.png" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 20, minute_posY: 139, minute_path: "mm_minute_hand.png" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
      
          function _tickSensorsNormal() {
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_3_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_4_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_4_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_5_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_5_battery_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_image_001 = createWidget(widget.IMG, { show_level: show_level.ONAL_AOD,
          x: 160, y: 290, w: 140, h: 140, src: "kubiki_140x140.png" });
          aod_w_0_image_001.setAlpha(255);
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONAL_AOD,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 34, hour_posY: 104, hour_path: "hh_hour_hand.png" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONAL_AOD,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 20, minute_posY: 139, minute_path: "mm_minute_hand.png" });
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
