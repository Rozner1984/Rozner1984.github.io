import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Battery, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _battery = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bezymyannyy_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_image_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 225, y: 150, w: 30, h: 20, src: "akum_30x20.png" });
          normal_w_0_image_001.setAlpha(255);
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          second_centerX: 250, second_centerY: 240, second_posX: 10, second_posY: 155, second_path: "shar_second_hand_second_hand_second_hand.png" });
          const normal_w_1_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 198, y: 180, w: 104, h: 42, text_size: 35, color: 0x121212, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 34, hour_posY: 104, hour_path: "hh_hour_hand_hour_hand.png" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 20, minute_posY: 139, minute_path: "mm_minute_hand_minute_hand.png" });
          const normal_w_2_image_004 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 225, y: 270, w: 30, h: 30, src: "puls_edited_30x30.png" });
          normal_w_2_image_004.setAlpha(255);
          const normal_w_3_heart_rate_002 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 190, y: 310, w: 100, h: 42, text_size: 35, color: 0x121212, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _battery = new Battery(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_1_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_1_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_3_heart_rate_002.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_heart_rate_002.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_image_001 = createWidget(widget.IMG, { show_level: show_level.ONAL_AOD,
          x: 160, y: 290, w: 140, h: 140, src: "kubiki_140x140.png" });
          aod_w_0_image_001.setAlpha(255);
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONAL_AOD,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 34, hour_posY: 104, hour_path: "hh_hour_hand.png" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONAL_AOD,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 20, minute_posY: 139, minute_path: "mm_minute_hand.png" });
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
