import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time, Step, Calorie, Distance, Barometer, Weather, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _step = null;
let _calorie = null;
let _distance = null;
let _barometer = null;
let _weatherFc = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bezymyannyy_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 80, y: 390, w: 100, h: 40, text_size: 35, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_10b251305f4a4d1795eec99642df991d_calibri.ttf", text: "--" });
          const normal_w_1_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 175, y: 391, w: 131, h: 40, text_size: 35, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_10b251305f4a4d1795eec99642df991d_calibri.ttf", text: "--" });
          const normal_w_2_distance_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 290, y: 390, w: 126, h: 40, text_size: 35, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_10b251305f4a4d1795eec99642df991d_calibri.ttf", text: "--" });
          const normal_w_3_weather_forecast_icon_001_weatherFiles = ["weather/64x64/0_cloudy.png","weather/64x64/1_showers.png","weather/64x64/2_snow_showers.png","weather/64x64/3_sunny.png","weather/64x64/4_overcast.png","weather/64x64/5_light_rain.png","weather/64x64/6_light_snow.png","weather/64x64/7_moderate_rain.png","weather/64x64/8_moderate_snow.png","weather/64x64/9_heavy_snow.png","weather/64x64/10_heavy_rain.png","weather/64x64/11_sandstorm.png","weather/64x64/12_rain_snow.png","weather/64x64/13_fog.png","weather/64x64/14_hazy.png","weather/64x64/15_thunderstorm.png","weather/64x64/16_snowstorm.png","weather/64x64/17_floating_dust.png","weather/64x64/18_very_heavy_rainstorm.png","weather/64x64/19_rain_hail.png","weather/64x64/20_thunderstorm_hail.png","weather/64x64/21_heavy_rainstorm.png","weather/64x64/22_dust.png","weather/64x64/23_heavy_sandstorm.png","weather/64x64/24_rainstorm.png","weather/64x64/25_unknown.png","weather/64x64/26_cloudy_night.png","weather/64x64/27_showers_night.png","weather/64x64/28_sunny_night.png"];
          const normal_w_3_weather_forecast_icon_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 50, w: 64, h: 64, src: "weather/64x64/3_sunny.png" });
          normal_w_3_weather_forecast_icon_001.setAlpha(255);
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 190, y: 60, w: 120, h: 48, text_size: 40, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_10b251305f4a4d1795eec99642df991d_calibri.ttf", type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_w_5_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 47, y: 211, w: 379, h: 170, text_size: 141, color: 0x00fdfd, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_10b251305f4a4d1795eec99642df991d_calibri.ttf", text: "" });
          // Набор картинок (STEP): 5 кадр(ов), крайние кадры на краях диапазона
          const normal_w_6_image_set_001_frames = ["shagi_1_2.png","shagi_2_2.png","shagi_3_2.png","shagi_4_2.png","shagi_5_2.png"];
          const normal_w_6_image_set_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 100, w: 230, h: 100, src: normal_w_6_image_set_001_frames[4] });
          let normal_w_6_image_set_001_cur = -1;
          function normal_w_6_image_set_001_set(r) {
            r = (typeof r === 'number' && isFinite(r)) ? Math.max(0, Math.min(1, r)) : 0;
            const i = Math.round(r * 4);
            if (i === normal_w_6_image_set_001_cur) return;
            normal_w_6_image_set_001_cur = i;
            try { normal_w_6_image_set_001.setProperty(prop.MORE, { src: normal_w_6_image_set_001_frames[i] }); } catch (e) {}
          }
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 277, y: 50, w: 80, h: 40, text_size: 27, color: 0xff9f7f, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_10b251305f4a4d1795eec99642df991d_calibri.ttf", type: data_type.WEATHER_HIGH, unit_type: 1 });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 270, y: 90, w: 90, h: 40, text_size: 27, color: 0x7fb8ff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_10b251305f4a4d1795eec99642df991d_calibri.ttf", type: data_type.WEATHER_LOW, unit_type: 1 });
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 310, w: 100, h: 36, text_size: 30, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WIND, unit_type: 1 });
          const normal_w_10_image_003 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 30, y: 270, w: 40, h: 40, src: "yschys_40x40.png" });
          normal_w_10_image_003.setAlpha(255);
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 380, y: 310, w: 100, h: 32, text_size: 26, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.HUMIDITY, unit_type: 1 });
          const normal_w_12_image_005 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 414, y: 270, w: 30, h: 30, src: "shshschzshz.png" });
          normal_w_12_image_005.setAlpha(255);
          const normal_w_13_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 367, y: 130, w: 167, h: 38, text_size: 31, color: 0x00ffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_10b251305f4a4d1795eec99642df991d_calibri.ttf", text: "--" });
          const normal_w_14_image_006 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 40, y: 100, w: 50, h: 60, src: "gora_50x60.png" });
          normal_w_14_image_006.setAlpha(255);
          const normal_w_15_altitude_003 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 8, y: 154, w: 120, h: 36, text_size: 30, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_10b251305f4a4d1795eec99642df991d_calibri.ttf", text: "--" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _distance = new Distance(); } catch (e) {}
          try { _barometer = new Barometer(); } catch (e) {}
          try { _weatherFc = new Weather(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_5_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_0_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_0_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_1_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_1_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const raw = _distance ? _distance.getCurrent() : null;
              // Единица возвращаемого значения в документации не указана (⚠) — принята за метры.
              let v = typeof raw === 'number' ? raw / 1000 : null;
              const txt = v !== null ? v.toFixed(2) : '--';
              normal_w_2_distance_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_2_distance_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const fc = _weatherFc ? _weatherFc.getForecast() : null;
              const it = (fc && fc.forecastData && fc.forecastData.data) ? fc.forecastData.data[0] : null;
              if (it && typeof it.index === 'number' && normal_w_3_weather_forecast_icon_001_weatherFiles[it.index]) normal_w_3_weather_forecast_icon_001.setProperty(prop.MORE, { src: normal_w_3_weather_forecast_icon_001_weatherFiles[it.index] });
            } catch (e) {}
            try {
              const v = _step ? _step.getCurrent() : null;
              normal_w_6_image_set_001_set(typeof v === 'number' ? (v - 0) / 12000 : 0);
            } catch (e) { normal_w_6_image_set_001_set(0); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_13_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_13_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _barometer ? _barometer.getAltitude() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_15_altitude_003.setProperty(prop.MORE, { text: "" + txt + " м" });
            } catch (e) { normal_w_15_altitude_003.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
