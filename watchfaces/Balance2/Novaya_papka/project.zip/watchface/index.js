import { createWidget, widget, align, text_style, prop, show_level, data_type, system_status } from '@zos/ui'
import { launchApp, SYSTEM_APP_STOPWATCH, SYSTEM_APP_WEATHER } from '@zos/router'
import { Battery, Step, Calorie, Distance, HeartRate, Time } from '@zos/sensor'
import { setInterval, clearInterval, setTimeout, clearTimeout } from '@zos/timer'

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _battery = null;
let _step = null;
let _calorie = null;
let _distance = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    const __afProfileWidgets = { day: [], night: [] };
    const __afProfileWidgetState = new Map();
    let __afActiveProfile = '';
    function __afCreateProfileWidget(profile, id, options) {
      const w = createWidget(id, options);
      const record = { widget: w, profile: profile, visible: true };
      __afProfileWidgetState.set(w, record);
      __afProfileWidgets[profile].push(record);
      try { w.setProperty(prop.VISIBLE, profile === __afActiveProfile); } catch (e) {}
      return w;
    }
    function __afCreateDayWidget(id, options) { return __afCreateProfileWidget('day', id, options); }
    function __afCreateNightWidget(id, options) { return __afCreateProfileWidget('night', id, options); }
    function __afSetProfileVisible(w, visible) {
      const record = __afProfileWidgetState.get(w);
      if (!record) { try { w.setProperty(prop.VISIBLE, !!visible); } catch (e) {} return; }
      record.visible = !!visible;
      try { w.setProperty(prop.VISIBLE, record.visible && record.profile === __afActiveProfile); } catch (e) {}
    }
    function __afProfileApply(profile) {
      profile = profile === 'night' ? 'night' : 'day';
      if (profile === __afActiveProfile) return;
      try { const offs = self._flashOffs || []; for (let i = 0; i < offs.length; i++) { try { offs[i](); } catch (e) {} } } catch (e) {}
      __afActiveProfile = profile;
      ['day', 'night'].forEach(function (key) {
        const list = __afProfileWidgets[key] || [];
        for (let i = 0; i < list.length; i++) {
          const record = list[i];
          try { record.widget.setProperty(prop.VISIBLE, record.visible && key === profile); } catch (e) {}
        }
      });
    }
    let __afProfileTime = null;
    try { __afProfileTime = new Time(); } catch (e) {}
    function __afProfileRefresh() {
      const mode = __afProfilePrefs.profileMode || 'day';
      let target = mode === 'night' ? 'night' : 'day';
      if (mode === 'auto') {
        const now = __afProfileTime ? new Date(__afProfileTime.getTime()) : new Date();
        const hour = now.getHours();
        const start = Number(__afProfilePrefs.profileStart);
        const end = Number(__afProfilePrefs.profileEnd);
        const night = start !== end && (start < end ? hour >= start && hour < end : hour >= start || hour < end);
        target = night ? 'night' : 'day';
      }
      __afProfileApply(target);
      try { if (typeof __afPanelRefresh === 'function') __afPanelRefresh(); } catch (e) {}
    }
    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "avto_sport_bg.png" });
          __bgImage_normal_.setAlpha(255);
          __afCreateDayWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 147, y: 194, w: 120, h: 48, text_size: 40, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_w_1_heart_rate_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 150, y: 250, w: 100, h: 42, text_size: 35, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_2_steps_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 153, y: 294, w: 150, h: 42, text_size: 35, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_3_calories_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 152, y: 336, w: 120, h: 42, text_size: 35, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const normal_w_4_image_001 = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 290, y: 290, w: 60, h: 60, src: "orig_60x60.png" });
          normal_w_4_image_001.setAlpha(255);
          const normal_w_5_battery_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 274, y: 350, w: 100, h: 38, text_size: 30, color: 0xfc0204, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afCreateDayWidget(widget.IMG_STATUS, { show_level: show_level.ONLY_NORMAL,
          x: 250, y: 70, w: 60, h: 60, type: system_status.DISCONNECT, src: "chek.png" });
          const normal_w_7_image_003 = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 271, y: 187, w: 100, h: 30, src: "probeg_100x30.png" });
          normal_w_7_image_003.setAlpha(255);
          const normal_w_8_distance_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 267, y: 225, w: 159, h: 38, text_size: 30, color: 0xfcfcfc, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afCreateDayWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 30, hour_posY: 29, hour_path: "hh_hour_hand_hour_hand.png" });
          __afCreateDayWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 21, minute_posY: 32, minute_path: "mm_minute_hand_minute_hand_minute_hand_minute_hand.png" });
          __afCreateDayWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          second_centerX: 240, second_centerY: 240, second_posX: 26, second_posY: 42, second_path: "ss_second_hand_second_hand_second_hand_second_hand_second_hand_second_hand.png" });
          const normal_tap_0_tap_zone_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 160, y: 130, w: 80, h: 60, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_0_tap_zone_001.setAlpha(0);
          const normal_tap_1_tap_zone_002 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 280, y: 290, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { if (typeof hmApp !== 'undefined' && hmApp.startApp) { hmApp.startApp({ url: "Settings_batteryManagerScreen", native: true }); } else { launchApp({ url: "Settings_batteryManagerScreen", native: true }); } } catch (e) {} } });
          normal_tap_1_tap_zone_002.setAlpha(0);
          const normal_tap_2_tap_zone_003 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 120, y: 250, w: 110, h: 120, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STOPWATCH, native: true }); } catch (e) {} } });
          normal_tap_2_tap_zone_003.setAlpha(0);
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _distance = new Distance(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickSensorsNormal() {
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_1_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_1_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_2_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_2_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_3_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_5_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_5_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const raw = _distance ? _distance.getCurrent() : null;
              // Единица возвращаемого значения в документации не указана (⚠) — принята за метры.
              let v = typeof raw === 'number' ? raw / 1000 : null;
              const txt = v !== null ? v.toFixed(2) : '--';
              normal_w_8_distance_001.setProperty(prop.MORE, { text: "" + txt + " km" });
            } catch (e) { normal_w_8_distance_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // Night profile widgets — isolated lexical scope
    {
          const __bgColor_night_ = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_night_.setAlpha(255);
          const __bgImage_night_ = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "avto_sport_bg.png" });
          __bgImage_night_.setAlpha(255);
          __afCreateNightWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 147, y: 194, w: 120, h: 48, text_size: 40, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const night_w_1_heart_rate_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 150, y: 250, w: 100, h: 42, text_size: 35, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const night_w_2_steps_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 153, y: 294, w: 150, h: 42, text_size: 35, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const night_w_3_calories_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 152, y: 336, w: 120, h: 42, text_size: 35, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          const night_w_4_image_001 = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 290, y: 290, w: 60, h: 60, src: "orig_60x60.png" });
          night_w_4_image_001.setAlpha(255);
          const night_w_5_battery_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 274, y: 350, w: 100, h: 38, text_size: 30, color: 0xfc0204, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afCreateNightWidget(widget.IMG_STATUS, { show_level: show_level.ONLY_NORMAL,
          x: 250, y: 70, w: 60, h: 60, type: system_status.DISCONNECT, src: "chek.png" });
          const night_w_7_image_003 = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 271, y: 187, w: 100, h: 30, src: "probeg_100x30.png" });
          night_w_7_image_003.setAlpha(255);
          const night_w_8_distance_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 267, y: 225, w: 159, h: 38, text_size: 30, color: 0xfcfcfc, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afCreateNightWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 30, hour_posY: 29, hour_path: "hh_hour_hand_hour_hand.png" });
          __afCreateNightWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 21, minute_posY: 32, minute_path: "mm_minute_hand_minute_hand_minute_hand_minute_hand.png" });
          __afCreateNightWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          second_centerX: 240, second_centerY: 240, second_posX: 26, second_posY: 42, second_path: "ss_second_hand_second_hand_second_hand_second_hand_second_hand_second_hand.png" });
          const night_tap_0_tap_zone_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 160, y: 130, w: 80, h: 60, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          night_tap_0_tap_zone_001.setAlpha(0);
          const night_tap_1_tap_zone_002 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 280, y: 290, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { if (typeof hmApp !== 'undefined' && hmApp.startApp) { hmApp.startApp({ url: "Settings_batteryManagerScreen", native: true }); } else { launchApp({ url: "Settings_batteryManagerScreen", native: true }); } } catch (e) {} } });
          night_tap_1_tap_zone_002.setAlpha(0);
          const night_tap_2_tap_zone_003 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 120, y: 250, w: 110, h: 120, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STOPWATCH, native: true }); } catch (e) {} } });
          night_tap_2_tap_zone_003.setAlpha(0);
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _distance = new Distance(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickSensorsNight() {
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              night_w_1_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_1_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              night_w_2_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_2_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              night_w_3_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_3_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              night_w_5_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { night_w_5_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const raw = _distance ? _distance.getCurrent() : null;
              // Единица возвращаемого значения в документации не указана (⚠) — принята за метры.
              let v = typeof raw === 'number' ? raw / 1000 : null;
              const txt = v !== null ? v.toFixed(2) : '--';
              night_w_8_distance_001.setProperty(prop.MORE, { text: "" + txt + " km" });
            } catch (e) { night_w_8_distance_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNight();
          self._sensorTimerNight = setInterval(_tickSensorsNight, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONAL_AOD,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 30, hour_posY: 29, hour_path: "hh_hour_hand_hour_hand.png" });
          createWidget(widget.TIME_POINTER, { show_level: show_level.ONAL_AOD,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 21, minute_posY: 32, minute_path: "mm_minute_hand_minute_hand_minute_hand_minute_hand.png" });
      
    }
    const __afProfilePrefs = { profileMode: "auto", profileStart: 22, profileEnd: 7 };
    __afProfileRefresh();
    self._dayNightTimer = setInterval(__afProfileRefresh, 30000);
    try { createWidget(widget.WIDGET_DELEGATE, { resume_call: function () { try { __afProfileRefresh(); } catch (e) {} } }); } catch (e) {}
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._timeTimerNight) { clearInterval(this._timeTimerNight); this._timeTimerNight = null; }
    if (this._sensorTimerNight) { clearInterval(this._sensorTimerNight); this._sensorTimerNight = null; }
    if (this._smoothTimerNight) { clearInterval(this._smoothTimerNight); this._smoothTimerNight = null; }
    if (this._dayNightTimer) { clearInterval(this._dayNightTimer); this._dayNightTimer = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
