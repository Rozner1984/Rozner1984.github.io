import { createWidget, widget, align, text_style, prop, show_level, data_type, system_status } from '@zos/ui'
import { Time, Battery, Step, Calorie, HeartRate, Screen } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "zepp_magaz_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_arc_001_track = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 50, y: 100, w: 141, h: 202, start_angle: -250, end_angle: 70, color: 0x470000, line_width: 5 });
          const normal_w_0_arc_001 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 50, y: 100, w: 141, h: 202, start_angle: -250, end_angle: -250, color: 0xec0909, line_width: 5 });
          // Дуга normal_w_0_arc_001: значение из источника HEART, углы на часах -250°…70° (0° = 3 часа)
          let normal_w_0_arc_001_target = 0, normal_w_0_arc_001_phase = 0, normal_w_0_arc_001_timer = null, normal_w_0_arc_001_err = false;
          function normal_w_0_arc_001_draw(r, f, g) {
            try {
              normal_w_0_arc_001.setProperty(prop.MORE, { x: 50, y: 100, w: 141, h: 202, start_angle: -250, end_angle: Math.round(-250 + (320) * r), color: 0xec0909, line_width: 5 });
            } catch (e) { if (!normal_w_0_arc_001_err) { normal_w_0_arc_001_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_0_arc_001_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_0_arc_001_target = v;
            if (normal_w_0_arc_001_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_0_arc_001_phase === 0) { normal_w_0_arc_001_phase = 1; normal_w_0_arc_001_run(); return; }
            normal_w_0_arc_001_draw(v, 1, 1);
          }
          function normal_w_0_arc_001_run() {
            let n = 0;
            normal_w_0_arc_001_draw(0, 0, 0);
            normal_w_0_arc_001_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = (1 - Math.pow(1 - (k), 3));
              normal_w_0_arc_001_draw(e * normal_w_0_arc_001_target, 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_0_arc_001_timer); normal_w_0_arc_001_timer = null; normal_w_0_arc_001_phase = 2;
                normal_w_0_arc_001_draw(normal_w_0_arc_001_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_0_arc_001_replay() {
            if (normal_w_0_arc_001_phase !== 2) return;
            normal_w_0_arc_001_phase = 1;
            normal_w_0_arc_001_run();
          }
          const normal_w_1_date_day_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 190, y: 182, w: 100, h: 40, text_size: 31, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_d3951faabec54b5c8ce563b8b75e4b6e_Dutch_809_BT.ttf", text: "" });
          const normal_w_2_weekday_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 177, y: 233, w: 130, h: 50, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c04ddd3152724bf3a5fcb3dc86cd7ed4_Roboto-Bold.ttf", text: "" });
          const normal_w_3_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 167, y: 90, w: 150, h: 36, text_size: 37, color: 0x050505, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_a68b09b7d9294121b2256a58a34c528b_Upsilon.ttf", text: "--" });
          const normal_w_4_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 67, y: 140, w: 110, h: 120, text_size: 35, color: 0xf0d68e, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c04ddd3152724bf3a5fcb3dc86cd7ed4_Roboto-Bold.ttf", text: "--" });
          const normal_w_5_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 280, y: 177, w: 170, h: 50, text_size: 35, color: 0xf0d68e, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c04ddd3152724bf3a5fcb3dc86cd7ed4_Roboto-Bold.ttf", text: "--" });
          const normal_w_6_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 190, y: 415, w: 120, h: 40, text_size: 30, color: 0xf7a003, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_c04ddd3152724bf3a5fcb3dc86cd7ed4_Roboto-Bold.ttf", text: "--" });
          createWidget(widget.IMG_STATUS, { show_level: show_level.ONLY_NORMAL,
          x: 69, y: 291, w: 43, h: 53, type: system_status.DISCONNECT, src: "blud.png" });
          createWidget(widget.IMG_STATUS, { show_level: show_level.ONLY_NORMAL,
          x: 368, y: 294, w: 52, h: 45, type: system_status.CLOCK, src: "bud.png" });
          const normal_w_9_time_hm_002 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 91, y: 310, w: 300, h: 100, text_size: 100, color: 0xf0d68e, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_60916efd82fd41ea895413e9596c15b1_CyrillicHelvet_Bold.ttf", text: "" });
          const normal_w_10_arc_004_track = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 290, y: 110, w: 140, h: 190, start_angle: -250, end_angle: 70, color: 0x470000, line_width: 5 });
          const normal_w_10_arc_004 = createWidget(widget.ARC, { show_level: show_level.ONLY_NORMAL,
          x: 290, y: 110, w: 140, h: 190, start_angle: -250, end_angle: -250, color: 0xec0909, line_width: 5 });
          // Дуга normal_w_10_arc_004: значение из источника HEART, углы на часах -250°…70° (0° = 3 часа)
          let normal_w_10_arc_004_target = 0, normal_w_10_arc_004_phase = 0, normal_w_10_arc_004_timer = null, normal_w_10_arc_004_err = false;
          function normal_w_10_arc_004_draw(r, f, g) {
            try {
              normal_w_10_arc_004.setProperty(prop.MORE, { x: 290, y: 110, w: 140, h: 190, start_angle: -250, end_angle: Math.round(-250 + (320) * r), color: 0xec0909, line_width: 5 });
            } catch (e) { if (!normal_w_10_arc_004_err) { normal_w_10_arc_004_err = true; try { console.log('ARC draw error: ' + e); } catch (e2) {} } }
          }
          function normal_w_10_arc_004_set(v) {
            v = (typeof v === 'number' && isFinite(v)) ? Math.max(0, Math.min(1, v)) : 0;
            normal_w_10_arc_004_target = v;
            if (normal_w_10_arc_004_phase === 1) return;           // идёт анимация — подхватит последнее значение
            if (normal_w_10_arc_004_phase === 0) { normal_w_10_arc_004_phase = 1; normal_w_10_arc_004_run(); return; }
            normal_w_10_arc_004_draw(v, 1, 1);
          }
          function normal_w_10_arc_004_run() {
            let n = 0;
            normal_w_10_arc_004_draw(0, 0, 0);
            normal_w_10_arc_004_timer = setInterval(() => {
              n++;
              if (n <= 0) return;
              const k = Math.min(1, (n - 0) / 30);
              const e = (1 - Math.pow(1 - (k), 3));
              normal_w_10_arc_004_draw(e * normal_w_10_arc_004_target, 1, 1);
              if (k >= 1) {
                clearInterval(normal_w_10_arc_004_timer); normal_w_10_arc_004_timer = null; normal_w_10_arc_004_phase = 2;
                normal_w_10_arc_004_draw(normal_w_10_arc_004_target, 1, 1);
              }
            }, 40);
          }
          function normal_w_10_arc_004_replay() {
            if (normal_w_10_arc_004_phase !== 2) return;
            normal_w_10_arc_004_phase = 1;
            normal_w_10_arc_004_run();
          }
      
          // Повтор анимации дуг при возврате на циферблат / пробуждении экрана
          try {
            createWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { console.log('watchface resume'); } catch (e) {}
                try { normal_w_0_arc_001_replay(); } catch (e) {}
                try { normal_w_10_arc_004_replay(); } catch (e) {}
              },
              pause_call: function () {},
            });
          } catch (e) {}
      
          // Повтор анимации дуг при поднятии руки (Screen.onChange + страховка по паузе таймера)
          try {
            const _scr = new Screen();
            let _scrPrev = 1;
            try { _scrPrev = _scr.getStatus(); } catch (e) {}
            const _raise = function (why) {
              try { console.log('arc replay: ' + why); } catch (e) {}
              try { normal_w_0_arc_001_replay(); } catch (e) {}
              try { normal_w_10_arc_004_replay(); } catch (e) {}
            };
            self._screen = _scr;
            self._screenCb = function (st) {
              try {
                const cur = (typeof st === 'number') ? st : _scr.getStatus();
                try { console.log('screen status: ' + cur); } catch (e) {}
                const was = _scrPrev; _scrPrev = cur;
                if (cur === 1 && was !== 1) _raise('screen on');
              } catch (e) {}
            };
            _scr.onChange(self._screenCb);
            let _hbLast = Date.now();
            self._raiseTimer = setInterval(function () {
              try {
                const t = Date.now();
                if (t - _hbLast > 3000) _raise('timer gap ' + (t - _hbLast) + ' ms');
                _hbLast = t;
              } catch (e) {}
            }, 1000);
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_1_date_day_001.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            normal_w_2_weekday_001.setProperty(prop.MORE, { text: formatWeekday(now, "EEE3", "RU") });
            normal_w_9_time_hm_002.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _heartVal;
              normal_w_0_arc_001_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { normal_w_0_arc_001_set(0); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_3_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_4_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_4_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_5_calories_001.setProperty(prop.MORE, { text: "" + txt + " " });
            } catch (e) { normal_w_5_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_6_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_6_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              normal_w_10_arc_004_set(typeof v === 'number' ? (v - 0) / 100 : 0);
            } catch (e) { normal_w_10_arc_004_set(0); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
