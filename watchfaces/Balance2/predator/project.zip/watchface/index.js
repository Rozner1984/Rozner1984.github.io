import { createWidget, widget, align, text_style, prop, show_level, data_type, system_status, anim_status } from '@zos/ui'
import { launchApp, SYSTEM_APP_CALENDAR, SYSTEM_APP_COUNTDOWN, SYSTEM_APP_HR, SYSTEM_APP_SPORT, SYSTEM_APP_STATUS, SYSTEM_APP_WEATHER } from '@zos/router'
import { Time, Battery, Step, Calorie, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bganim/f_0.png" });
          __bgImage_normal_.setAlpha(255);
          const __bgAnim_normal_ = createWidget(widget.IMG_ANIM, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, anim_path: "bganim", anim_prefix: "f", anim_ext: "png", anim_fps: 17, anim_size: 17, repeat_count: 0, anim_status: anim_status.START, display_on_restart: false });
          const normal_w_0_image_001 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 1, y: 10, w: 478, h: 474, src: "watch_overlay_480_478x474.png" });
          normal_w_0_image_001.setAlpha(255);
          const normal_w_1_time_hms_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 60, y: 110, w: 367, h: 231, text_size: 75, color: 0xde2518, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_cc9126870bf14ed88dee8efe1e24e54a_DigitalNormal-xO6j.ttf", text: "" });
          const normal_w_2_heart_rate_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 87, y: 299, w: 100, h: 42, text_size: 35, color: 0xde2518, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_cc9126870bf14ed88dee8efe1e24e54a_DigitalNormal-xO6j.ttf", text: "--" });
          const normal_w_3_steps_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 228, y: 300, w: 188, h: 42, text_size: 35, color: 0xde2518, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_cc9126870bf14ed88dee8efe1e24e54a_DigitalNormal-xO6j.ttf", text: "--" });
          const normal_w_4_calories_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 105, y: 360, w: 131, h: 42, text_size: 35, color: 0xde2518, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_cc9126870bf14ed88dee8efe1e24e54a_DigitalNormal-xO6j.ttf", text: "--" });
          const normal_w_5_battery_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 280, y: 360, w: 100, h: 42, text_size: 35, color: 0xde2518, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_cc9126870bf14ed88dee8efe1e24e54a_DigitalNormal-xO6j.ttf", text: "--" });
          const normal_w_6_image_004 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 175, y: -18, w: 130, h: 130, src: "maska_130x130.png" });
          normal_w_6_image_004.setAlpha(255);
          const normal_w_7_image_005 = createWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 150, y: 410, w: 180, h: 50, src: "temperatura_180x50.png" });
          normal_w_7_image_005.setAlpha(255);
          createWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 182, y: 410, w: 120, h: 48, text_size: 40, color: 0xde2518, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_cc9126870bf14ed88dee8efe1e24e54a_DigitalNormal-xO6j.ttf", type: data_type.WEATHER_CURRENT, unit_type: 1 });
          const normal_w_9_weekday_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 100, y: 138, w: 120, h: 48, text_size: 35, color: 0xfe0000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_10_date_day_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 200, y: 140, w: 80, h: 42, text_size: 35, color: 0xde2518, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          const normal_w_11_date_month_001 = createWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 270, y: 134, w: 100, h: 47, text_size: 40, color: 0xde2518, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          createWidget(widget.IMG_STATUS, { show_level: show_level.ONLY_NORMAL,
          x: 84, y: 142, w: 32, h: 32, type: system_status.DISCONNECT, src: "blutus_32x32.png" });
          createWidget(widget.IMG_STATUS, { show_level: show_level.ONLY_NORMAL,
          x: 370, y: 143, w: 32, h: 32, type: system_status.CLOCK, src: "budilnik_32x32.png" });
          const normal_tap_0_tap_zone_001 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 70, y: 190, w: 350, h: 70, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_COUNTDOWN, native: true }); } catch (e) {} } });
          normal_tap_0_tap_zone_001.setAlpha(0);
          const normal_tap_1_tap_zone_002 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 140, w: 230, h: 40, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_CALENDAR, native: true }); } catch (e) {} } });
          normal_tap_1_tap_zone_002.setAlpha(0);
          const normal_tap_2_tap_zone_003 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 270, w: 80, h: 60, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_HR, native: true }); } catch (e) {} } });
          normal_tap_2_tap_zone_003.setAlpha(0);
          const normal_tap_3_tap_zone_004 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 160, y: 410, w: 140, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_WEATHER, native: true }); } catch (e) {} } });
          normal_tap_3_tap_zone_004.setAlpha(0);
          const normal_tap_4_tap_zone_005 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 260, y: 340, w: 120, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { if (typeof hmApp !== 'undefined' && hmApp.startApp) { hmApp.startApp({ url: "Settings_batteryManagerScreen", native: true }); } else { launchApp({ url: "Settings_batteryManagerScreen", native: true }); } } catch (e) {} } });
          normal_tap_4_tap_zone_005.setAlpha(0);
          const normal_tap_5_tap_zone_006 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 340, w: 120, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STATUS, native: true }); } catch (e) {} } });
          normal_tap_5_tap_zone_006.setAlpha(0);
          const normal_tap_6_tap_zone_007 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 280, y: 280, w: 80, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_STATUS, native: true }); } catch (e) {} } });
          normal_tap_6_tap_zone_007.setAlpha(0);
          const normal_tap_7_tap_zone_008 = createWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 200, y: 0, w: 80, h: 80, normal_src: "", press_src: "", enable: true, click_func: () => { try { launchApp({ appId: SYSTEM_APP_SPORT, native: true }); } catch (e) {} } });
          normal_tap_7_tap_zone_008.setAlpha(0);
      
          // Анимация текста: пауза при уходе с циферблата, повтор при пробуждении экрана
          try {
            createWidget(widget.WIDGET_DELEGATE, {
              resume_call: function () {
                try { __bgAnim_normal_.setProperty(prop.ANIM_STATUS, anim_status.START); } catch (e) {}
              },
              pause_call: function () { try { __bgAnim_normal_.setProperty(prop.ANIM_STATUS, anim_status.STOP); } catch (e) {} },
            });
          } catch (e) {}
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_1_time_hms_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", true) });
            normal_w_9_weekday_001.setProperty(prop.MORE, { text: formatWeekday(now, "EEE", "RU") });
            normal_w_10_date_day_001.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
            normal_w_11_date_month_001.setProperty(prop.MORE, { text: formatMonth(now, "MMM", "RU") });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_2_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_2_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_3_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_3_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_4_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_4_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_5_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_5_battery_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_time_hms_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 25, y: 93, w: 443, h: 282, text_size: 94, color: 0xde2518, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, font: "fonts/font_cc9126870bf14ed88dee8efe1e24e54a_DigitalNormal-xO6j.ttf", text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_time_hms_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", true) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
