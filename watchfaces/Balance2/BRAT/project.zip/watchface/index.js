import { createWidget, widget, align, text_style, prop, show_level, data_type } from '@zos/ui'
import { Time, Battery, Step, Calorie, Weather, HeartRate } from '@zos/sensor'
import { setInterval, clearInterval, setTimeout, clearTimeout } from '@zos/timer'

const WD_EN = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const WD_EN_FULL = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
const WD_RU = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];
const WD_RU_3 = ['ВОС', 'ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ'];
const WD_RU_FULL = ['ВОСКРЕСЕНЬЕ', 'ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА'];
const MO_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MO_EN_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const MO_RU = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
const MO_RU_FULL = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];

function pad2(n) { n = Math.floor(n); return n < 10 ? ('0' + n) : String(n); }
function formatUnit(n, lead) { return lead ? pad2(n) : String(Math.floor(n)); }
function formatClock(now, hour12, lead, sep, withSeconds) {
  let h = now.getHours();
  if (hour12) { h = h % 12; if (h === 0) h = 12; }
  let out = (lead ? pad2(h) : String(h)) + sep + pad2(now.getMinutes());
  if (withSeconds) out += sep + pad2(now.getSeconds());
  return out;
}
function formatAmpm(now, caseOpt) {
  const v = now.getHours() < 12 ? 'AM' : 'PM';
  return caseOpt === 'am/pm' ? v.toLowerCase() : v;
}
function formatHour(now, fmt, lead) {
  let h = now.getHours();
  if (fmt === 'hh') { h = h % 12; if (h === 0) h = 12; }
  return lead ? pad2(h) : String(h);
}
function formatDate(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD') return dd;
  if (fmt === 'MM') return mm;
  if (fmt === 'YYYY') return yyyy;
  if (fmt === 'DD.MM') return dd + '.' + mm;
  if (fmt === 'DD MMM') return dd + ' ' + MS[now.getMonth()];
  if (fmt === 'MMM DD') return MS[now.getMonth()] + ' ' + dd;
  if (fmt === 'DD MMMM') return dd + ' ' + MF[now.getMonth()];
  if (fmt === 'DD/MM') return dd + '/' + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + '-' + mm + '-' + dd;
  return dd + '.' + mm + '.' + yyyy;
}
function formatWeekday(now, fmt, locale) {
  const W = locale === 'RU' ? (fmt === 'EEEE' ? WD_RU_FULL : (fmt === 'EEE3' ? WD_RU_3 : WD_RU)) : (fmt === 'EEEE' ? WD_EN_FULL : WD_EN);
  return W[now.getDay()];
}
function formatMonth(now, fmt, locale) {
  const MS = locale === 'RU' ? MO_RU : MO_EN, MF = locale === 'RU' ? MO_RU_FULL : MO_EN_FULL;
  if (fmt === 'MMM') return MS[now.getMonth()];
  if (fmt === 'MMMM') return MF[now.getMonth()];
  if (fmt === 'M') return String(now.getMonth() + 1);
  return pad2(now.getMonth() + 1);
}
function formatDigitalDate(now, fmt, sep) {
  const dd = pad2(now.getDate()), mm = pad2(now.getMonth() + 1), yyyy = String(now.getFullYear());
  if (fmt === 'DD.MM') return dd + sep + mm;
  if (fmt === 'YYYY-MM-DD') return yyyy + sep + mm + sep + dd;
  return dd + sep + mm + sep + yyyy;
}
function formatYear(now, fmt) {
  const y = now.getFullYear();
  return fmt === 'YY' ? String(y).slice(-2) : String(y);
}

const WEATHER_ICON_FILES = ["0_cloudy.png","1_showers.png","2_snow_showers.png","3_sunny.png","4_overcast.png","5_light_rain.png","6_light_snow.png","7_moderate_rain.png","8_moderate_snow.png","9_heavy_snow.png","10_heavy_rain.png","11_sandstorm.png","12_rain_snow.png","13_fog.png","14_hazy.png","15_thunderstorm.png","16_snowstorm.png","17_floating_dust.png","18_very_heavy_rainstorm.png","19_rain_hail.png","20_thunderstorm_hail.png","21_heavy_rainstorm.png","22_dust.png","23_heavy_sandstorm.png","24_rainstorm.png","25_unknown.png","26_cloudy_night.png","27_showers_night.png","28_sunny_night.png"];

// Датчики создаются один раз в build(); переменные — на уровне модуля,
// чтобы вспомогательные функции ниже их видели.
let _time = null;
let _battery = null;
let _step = null;
let _calorie = null;
let _weatherFc = null;
let _heart = null;
let _heartVal = null;   // последний известный пульс: обновляется колбэками датчика, а не опросом
let _heartCb = null;
function __heartStart() {
  if (!_heart || _heartCb) return;
  // HeartRate.getCurrent() сам по себе значение не обновляет: оно появляется только внутри
  // onCurrentChange (непрерывное измерение), а разовые замеры (в т.ч. из приложения «Пульс»,
  // которое открывает тап-зона) приходят через onLastChange/getLast().
  _heartCb = {
    cur: () => { try { const v = _heart.getCurrent(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
    last: () => { try { const v = _heart.getLast(); if (typeof v === 'number' && v > 0) _heartVal = v; } catch (e) {} },
  };
  try { _heartCb.last(); } catch (e) {}
  try { _heart.onCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.onLastChange(_heartCb.last); } catch (e) {}
}
function __heartStop() {
  if (!_heart || !_heartCb) return;
  try { _heart.offCurrentChange(_heartCb.cur); } catch (e) {}
  try { _heart.offLastChange(_heartCb.last); } catch (e) {}
  _heartCb = null;
}

// Day, Night and AOD profiles are exported into one watchface.
// AOD follows show_level; Day/Night use tracked widget visibility.
WatchFace({
  build() {
    const self = this;

    const __afEd = [];

    const __afProfileWidgets = { day: [], night: [] };
    const __afProfileWidgetState = new Map();
    let __afActiveProfile = '';
    function __afCreateProfileWidget(profile, id, options) {
      const w = createWidget(id, options);
      const record = { widget: w, profile: profile, visible: true };
      __afProfileWidgetState.set(w, record);
      __afProfileWidgets[profile].push(record);
      try { w.setProperty(prop.VISIBLE, profile === __afActiveProfile); } catch (e) {}
      return w;
    }
    function __afCreateDayWidget(id, options) { return __afCreateProfileWidget('day', id, options); }
    function __afCreateNightWidget(id, options) { return __afCreateProfileWidget('night', id, options); }
    function __afSetProfileVisible(w, visible) {
      const record = __afProfileWidgetState.get(w);
      if (!record) { try { w.setProperty(prop.VISIBLE, !!visible); } catch (e) {} return; }
      record.visible = !!visible;
      try { w.setProperty(prop.VISIBLE, record.visible && record.profile === __afActiveProfile); } catch (e) {}
    }
    function __afProfileApply(profile) {
      profile = profile === 'night' ? 'night' : 'day';
      if (profile === __afActiveProfile) return;
      try { const offs = self._flashOffs || []; for (let i = 0; i < offs.length; i++) { try { offs[i](); } catch (e) {} } } catch (e) {}
      __afActiveProfile = profile;
      ['day', 'night'].forEach(function (key) {
        const list = __afProfileWidgets[key] || [];
        for (let i = 0; i < list.length; i++) {
          const record = list[i];
          try { record.widget.setProperty(prop.VISIBLE, record.visible && key === profile); } catch (e) {}
        }
      });
    }
    let __afProfileTime = null;
    try { __afProfileTime = new Time(); } catch (e) {}
    function __afProfileRefresh() {
      const mode = __afProfilePrefs.profileMode || 'day';
      let target = mode === 'night' ? 'night' : 'day';
      if (mode === 'auto') {
        const now = __afProfileTime ? new Date(__afProfileTime.getTime()) : new Date();
        const hour = now.getHours();
        const start = Number(__afProfilePrefs.profileStart);
        const end = Number(__afProfilePrefs.profileEnd);
        const night = start !== end && (start < end ? hour >= start && hour < end : hour >= start || hour < end);
        target = night ? 'night' : 'day';
      }
      __afProfileApply(target);
      try { if (typeof __afPanelRefresh === 'function') __afPanelRefresh(); } catch (e) {}
    }
    // Day profile widgets — isolated lexical scope
    {
          const __bgColor_normal_ = __afCreateDayWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_normal_.setAlpha(255);
          const __bgImage_normal_ = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bg1_bg.png" });
          __bgImage_normal_.setAlpha(255);
          const normal_w_0_time_hm_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: -66, y: 150, w: 300, h: 100, text_size: 85, color: 0x121212, align_h: align.RIGHT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "time_hm_001", n: "Время (ЧЧ:ММ", d: "TIME", h: normal_w_0_time_hm_001, x: -66, y: 150, w: 300, ht: 100, s: 85, c: 0x121212, ah: "RIGHT" });
          const normal_w_1_weekday_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 80, y: 240, w: 150, h: 40, text_size: 30, color: 0x000000, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "weekday_001", n: "День недели", d: "WEEKDAY", h: normal_w_1_weekday_001, x: 80, y: 240, w: 150, ht: 40, s: 30, c: 0x000000, ah: "LEFT" });
          const normal_w_2_date_day_003 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: -30, y: 190, w: 150, h: 130, text_size: 45, color: 0x000000, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "date_day_003", n: "День (ДД)", d: "DAY", h: normal_w_2_date_day_003, x: -30, y: 190, w: 150, ht: 130, s: 45, c: 0x000000, ah: "CENTER_H" });
          const normal_w_3_battery_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 340, y: 280, w: 100, h: 36, text_size: 30, color: 0x2ddf2a, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "battery_001", n: "Заряд батаре", d: "BATTERY", h: normal_w_3_battery_001, x: 340, y: 280, w: 100, ht: 36, s: 30, c: 0x2ddf2a, ah: "CENTER_H" });
          const normal_w_4_steps_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 395, w: 150, h: 36, text_size: 28, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "steps_001", n: "Шаги", d: "STEP", h: normal_w_4_steps_001, x: 90, y: 395, w: 150, ht: 36, s: 28, c: 0xffffff, ah: "LEFT" });
          const normal_w_5_calories_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 190, y: 400, w: 120, h: 32, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "calories_001", n: "Калории", d: "CALORIE", h: normal_w_5_calories_001, x: 190, y: 400, w: 120, ht: 32, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const normal_w_6_heart_rate_001 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 306, y: 398, w: 100, h: 36, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "heart_rate_001", n: "Пульс", d: "HEART", h: normal_w_6_heart_rate_001, x: 306, y: 398, w: 100, ht: 36, s: 28, c: 0xffffff, ah: "CENTER_H" });
          __afCreateDayWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 33, hour_posY: 170, hour_path: "hh_hour_hand_2.png" });
          __afCreateDayWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 29, minute_posY: 205, minute_path: "mm_minute_hand_2.png" });
          // Секундная стрелка: плавный ход не подтверждён официальной документацией
          // (⚠ unverified) — отдельный IMG сохраняет порядок слоя.
          const normal_w_second_smooth_235 = __afCreateDayWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "ss_second_hand_second_hand_second_hand_second_hand.png", pos_x: 220, pos_y: 15, center_x: 239, center_y: 240 });
          const normal_w_7_weather_icon_001 = __afCreateDayWidget(widget.IMG_LEVEL, { show_level: show_level.ONLY_NORMAL,
          x: 132, y: 20, w: 70, h: 60, image_array: ["weather/70x60/0_cloudy.png", "weather/70x60/1_showers.png", "weather/70x60/2_snow_showers.png", "weather/70x60/3_sunny.png", "weather/70x60/4_overcast.png", "weather/70x60/5_light_rain.png", "weather/70x60/6_light_snow.png", "weather/70x60/7_moderate_rain.png", "weather/70x60/8_moderate_snow.png", "weather/70x60/9_heavy_snow.png", "weather/70x60/10_heavy_rain.png", "weather/70x60/11_sandstorm.png", "weather/70x60/12_rain_snow.png", "weather/70x60/13_fog.png", "weather/70x60/14_hazy.png", "weather/70x60/15_thunderstorm.png", "weather/70x60/16_snowstorm.png", "weather/70x60/17_floating_dust.png", "weather/70x60/18_very_heavy_rainstorm.png", "weather/70x60/19_rain_hail.png", "weather/70x60/20_thunderstorm_hail.png", "weather/70x60/21_heavy_rainstorm.png", "weather/70x60/22_dust.png", "weather/70x60/23_heavy_sandstorm.png", "weather/70x60/24_rainstorm.png", "weather/70x60/25_unknown.png", "weather/70x60/26_cloudy_night.png", "weather/70x60/27_showers_night.png", "weather/70x60/28_sunny_night.png"], image_length: 29, type: data_type.WEATHER_CURRENT, default_frame_index: 12, alpha: 255 });
          const normal_w_8_weather_temp_001 = __afCreateDayWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 110, y: 100, w: 120, h: 40, text_size: 40, color: 0x0a0a0a, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          __afEd.push({ id: "weather_temp_001", n: "Температура", d: "WEATHER_TEMP", h: normal_w_8_weather_temp_001, x: 110, y: 100, w: 120, ht: 40, s: 40, c: 0x0a0a0a, ah: "CENTER_H" });
          const normal_w_9_text_003 = __afCreateDayWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 140, y: 140, w: 200, h: 50, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "text_003", n: "Текст", d: "", h: normal_w_9_text_003, x: 140, y: 140, w: 200, ht: 50, s: 36, c: 0xffffff, ah: "CENTER_H" });
          const normal_tap_0_tap_001 = __afCreateDayWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 240, y: 100, w: 200, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afOpenSettings(); } catch (e) {} } });
          normal_tap_0_tap_001.setAlpha(0);
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNormal() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            normal_w_0_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            normal_w_1_weekday_001.setProperty(prop.MORE, { text: formatWeekday(now, "EEEE", "RU") });
            normal_w_2_date_day_003.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
          }
          _tickNormal();
          self._timeTimerNormal = setInterval(_tickNormal, 1000);
      
          function _tickSensorsNormal() {
            try {
              const v = _battery ? _battery.getCurrent() : null;
              normal_w_3_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { normal_w_3_battery_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              normal_w_4_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_4_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              normal_w_5_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_5_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              normal_w_6_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { normal_w_6_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNormal();
          self._sensorTimerNormal = setInterval(_tickSensorsNormal, 5000);
      
          self._smoothTimerNormal = setInterval(() => {
            try {
              const now = _time ? new Date(_time.getTime()) : new Date();
              let deg = (now.getSeconds() + now.getMilliseconds() / 1000) * 6;
              normal_w_second_smooth_235.setProperty(prop.MORE, { angle: deg });
            } catch (e) {
              if (self._smoothTimerNormal) { clearInterval(self._smoothTimerNormal); self._smoothTimerNormal = null; }
            }
          }, 67);
      
    }

    // Night profile widgets — isolated lexical scope
    {
          const __bgColor_night_ = __afCreateNightWidget(widget.FILL_RECT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_night_.setAlpha(255);
          const __bgImage_night_ = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "bg2_bg.png" });
          __bgImage_night_.setAlpha(255);
          const night_w_0_weather_forecast_icon_001_weatherFiles = ["weather/64x64/0_cloudy.png","weather/64x64/1_showers.png","weather/64x64/2_snow_showers.png","weather/64x64/3_sunny.png","weather/64x64/4_overcast.png","weather/64x64/5_light_rain.png","weather/64x64/6_light_snow.png","weather/64x64/7_moderate_rain.png","weather/64x64/8_moderate_snow.png","weather/64x64/9_heavy_snow.png","weather/64x64/10_heavy_rain.png","weather/64x64/11_sandstorm.png","weather/64x64/12_rain_snow.png","weather/64x64/13_fog.png","weather/64x64/14_hazy.png","weather/64x64/15_thunderstorm.png","weather/64x64/16_snowstorm.png","weather/64x64/17_floating_dust.png","weather/64x64/18_very_heavy_rainstorm.png","weather/64x64/19_rain_hail.png","weather/64x64/20_thunderstorm_hail.png","weather/64x64/21_heavy_rainstorm.png","weather/64x64/22_dust.png","weather/64x64/23_heavy_sandstorm.png","weather/64x64/24_rainstorm.png","weather/64x64/25_unknown.png","weather/64x64/26_cloudy_night.png","weather/64x64/27_showers_night.png","weather/64x64/28_sunny_night.png"];
          const night_w_0_weather_forecast_icon_001 = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 130, y: 40, w: 64, h: 64, src: "weather/64x64/3_sunny.png" });
          night_w_0_weather_forecast_icon_001.setAlpha(255);
          const night_w_1_weather_temp_001 = __afCreateNightWidget(widget.TEXT_FONT, { show_level: show_level.ONLY_NORMAL,
          x: 110, y: 120, w: 120, h: 40, text_size: 40, color: 0x030303, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, type: data_type.WEATHER_CURRENT, unit_type: 1 });
          __afEd.push({ id: "night:weather_temp_001", n: "Температура", d: "WEATHER_TEMP", h: night_w_1_weather_temp_001, x: 110, y: 120, w: 120, ht: 40, s: 40, c: 0x030303, ah: "CENTER_H" });
          const night_w_2_time_hm_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: -66, y: 160, w: 300, h: 100, text_size: 85, color: 0x000000, align_h: align.RIGHT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "night:time_hm_001", n: "Время (ЧЧ:ММ", d: "TIME", h: night_w_2_time_hm_001, x: -66, y: 160, w: 300, ht: 100, s: 85, c: 0x000000, ah: "RIGHT" });
          const night_w_3_steps_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 90, y: 390, w: 150, h: 36, text_size: 28, color: 0xffffff, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:steps_001", n: "Шаги", d: "STEP", h: night_w_3_steps_001, x: 90, y: 390, w: 150, ht: 36, s: 28, c: 0xffffff, ah: "LEFT" });
          const night_w_4_calories_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 190, y: 391, w: 120, h: 32, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:calories_001", n: "Калории", d: "CALORIE", h: night_w_4_calories_001, x: 190, y: 391, w: 120, ht: 32, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const night_w_5_heart_rate_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 307, y: 390, w: 100, h: 36, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:heart_rate_001", n: "Пульс", d: "HEART", h: night_w_5_heart_rate_001, x: 307, y: 390, w: 100, ht: 36, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const night_w_6_battery_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 343, y: 280, w: 100, h: 36, text_size: 28, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "--" });
          __afEd.push({ id: "night:battery_001", n: "Заряд батаре", d: "BATTERY", h: night_w_6_battery_001, x: 343, y: 280, w: 100, ht: 36, s: 28, c: 0xffffff, ah: "CENTER_H" });
          const night_w_7_weekday_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 78, y: 257, w: 180, h: 30, text_size: 30, color: 0x0d0d0d, align_h: align.LEFT, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "night:weekday_001", n: "День недели", d: "WEEKDAY", h: night_w_7_weekday_001, x: 78, y: 257, w: 180, ht: 30, s: 30, c: 0x0d0d0d, ah: "LEFT" });
          const night_w_8_date_day_001 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 250, w: 80, h: 40, text_size: 45, color: 0x0a0a0a, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "night:date_day_001", n: "День (ДД)", d: "DAY", h: night_w_8_date_day_001, x: 0, y: 250, w: 80, ht: 40, s: 45, c: 0x0a0a0a, ah: "CENTER_H" });
          __afCreateNightWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          hour_centerX: 240, hour_centerY: 240, hour_posX: 32, hour_posY: 170, hour_path: "hh_hour_hand_hour_hand_2.png" });
          __afCreateNightWidget(widget.TIME_POINTER, { show_level: show_level.ONLY_NORMAL,
          minute_centerX: 240, minute_centerY: 240, minute_posX: 26, minute_posY: 205, minute_path: "mm_minute_hand_3.png" });
          // Секундная стрелка: плавный ход не подтверждён официальной документацией
          // (⚠ unverified) — отдельный IMG сохраняет порядок слоя.
          const night_w_second_smooth_241 = __afCreateNightWidget(widget.IMG, { show_level: show_level.ONLY_NORMAL,
          x: 0, y: 0, w: 480, h: 480, src: "ss_second_hand_2.png", pos_x: 226, pos_y: 15, center_x: 240, center_y: 240 });
          const night_w_9_text_002 = __afCreateNightWidget(widget.TEXT, { show_level: show_level.ONLY_NORMAL,
          x: 190, y: 160, w: 200, h: 50, text_size: 36, color: 0xffffff, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
          __afEd.push({ id: "night:text_002", n: "Текст", d: "", h: night_w_9_text_002, x: 190, y: 160, w: 200, ht: 50, s: 36, c: 0xffffff, ah: "CENTER_H" });
          const night_tap_0_tap_001 = __afCreateNightWidget(widget.BUTTON, { show_level: show_level.ONLY_NORMAL,
          x: 250, y: 90, w: 200, h: 50, normal_src: "", press_src: "", enable: true, click_func: () => { try { __afOpenSettings(); } catch (e) {} } });
          night_tap_0_tap_001.setAlpha(0);
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
          try { _battery = new Battery(); } catch (e) {}
          try { _step = new Step(); } catch (e) {}
          try { _calorie = new Calorie(); } catch (e) {}
          try { _weatherFc = new Weather(); } catch (e) {}
          try { _heart = new HeartRate(); __heartStart(); } catch (e) {}
      
          function _tickNight() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            night_w_2_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
            night_w_7_weekday_001.setProperty(prop.MORE, { text: formatWeekday(now, "EEEE", "RU") });
            night_w_8_date_day_001.setProperty(prop.MORE, { text: formatUnit(now.getDate(), true) });
          }
          _tickNight();
          self._timeTimerNight = setInterval(_tickNight, 1000);
      
          function _tickSensorsNight() {
            try {
              const fc = _weatherFc ? _weatherFc.getForecast() : null;
              const it = (fc && fc.forecastData && fc.forecastData.data) ? fc.forecastData.data[1] : null;
              if (it && typeof it.index === 'number' && night_w_0_weather_forecast_icon_001_weatherFiles[it.index]) night_w_0_weather_forecast_icon_001.setProperty(prop.MORE, { src: night_w_0_weather_forecast_icon_001_weatherFiles[it.index] });
            } catch (e) {}
            try {
              const v = _step ? _step.getCurrent() : null;
              const txt = typeof v === 'number' ? (false ? v.toLocaleString('en-US') : String(v)) : '--';
              night_w_3_steps_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_3_steps_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _calorie ? _calorie.getCurrent() : null;
              const txt = typeof v === 'number' ? v.toFixed(0) : '--';
              night_w_4_calories_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_4_calories_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _heartVal;
              const txt = (typeof v === 'number' && v >= 30) ? String(v) : '--';
              night_w_5_heart_rate_001.setProperty(prop.MORE, { text: "" + txt + "" });
            } catch (e) { night_w_5_heart_rate_001.setProperty(prop.MORE, { text: '--' }); }
            try {
              const v = _battery ? _battery.getCurrent() : null;
              night_w_6_battery_001.setProperty(prop.MORE, { text: (typeof v === 'number' ? "" + v + "%" : '--') });
            } catch (e) { night_w_6_battery_001.setProperty(prop.MORE, { text: '--' }); }
          }
          _tickSensorsNight();
          self._sensorTimerNight = setInterval(_tickSensorsNight, 5000);
      
          self._smoothTimerNight = setInterval(() => {
            try {
              const now = _time ? new Date(_time.getTime()) : new Date();
              let deg = (now.getSeconds() + now.getMilliseconds() / 1000) * 6;
              night_w_second_smooth_241.setProperty(prop.MORE, { angle: deg });
            } catch (e) {
              if (self._smoothTimerNight) { clearInterval(self._smoothTimerNight); self._smoothTimerNight = null; }
            }
          }, 50);
      
    }

    // AOD scene widgets — isolated lexical scope
    {
          const __bgColor_aod_ = createWidget(widget.FILL_RECT, { show_level: show_level.ONAL_AOD,
          x: 0, y: 0, w: 480, h: 480, color: 0x000000 });
          __bgColor_aod_.setAlpha(255);
          const aod_w_0_time_hm_001 = createWidget(widget.TEXT, { show_level: show_level.ONAL_AOD,
          x: 88, y: 150, w: 300, h: 171, text_size: 119, color: 0xe21818, align_h: align.CENTER_H, align_v: align.CENTER_V, text_style: text_style.NONE, text: "" });
      
          // Датчики создаются один раз — try/catch на случай недоступности на симуляторе.
          try { _time = new Time(); } catch (e) {}
      
          function _tickAod() {
            const now = _time ? new Date(_time.getTime()) : new Date();
            aod_w_0_time_hm_001.setProperty(prop.MORE, { text: formatClock(now, false, true, ":", false) });
          }
          _tickAod();
          self._timeTimerAod = setInterval(_tickAod, 1000);
      
    }
// Параметры расписания живут только в памяти текущего запуска циферблата.
    const __afPanelW = 480;
    const __afPanelH = 480;
    const __afProfilePrefs = { profileMode: "auto", profileStart: 23, profileEnd: 7 };

    const __afPanelScale = Math.min(__afPanelW, __afPanelH) / 480;
    const __afPanelPad = Math.max(6, Math.round(10 * __afPanelScale));
    const __afPanelSafePad = Math.max(6, Math.round(12 * __afPanelScale));
    // Шапка ниже и выше прежней: у верха круглого экрана по ширине помещается меньше 40 px.
    const __afPanelHeaderH = Math.min(__afPanelH, Math.max(40, Math.round(68 * __afPanelScale)));
    const __afPanelHeaderTop = Math.round(22 * __afPanelScale);
    const __afPanelBottomPad = Math.max(8, Math.round(12 * __afPanelScale));
    const __afPanelRowH = Math.max(16, Math.min(
      Math.max(18, Math.round(44 * __afPanelScale)),
      Math.floor((__afPanelH - __afPanelHeaderH - __afPanelPad - __afPanelBottomPad) / 10)
    ));
    const __afPanelHeight = Math.min(__afPanelH, __afPanelHeaderH + 10 * __afPanelRowH + __afPanelPad + __afPanelBottomPad);
    const __afPanelTop = __afPanelH - __afPanelHeight;
    const __afPanelRowY = __afPanelTop + __afPanelHeaderH + __afPanelPad;
    const __afPanelFont = Math.max(12, Math.min(Math.round(20 * __afPanelScale), Math.round((__afPanelRowH - 2) * 0.62)));
    const __afPanelStepW = Math.max(24, Math.round(46 * __afPanelScale));
    let __afPanelVisible = false;
    let __afPanelPage = 0;
    function __afPanelCircleInset(y) {
      const halfW = __afPanelW / 2;
      const halfH = __afPanelH / 2;
      const normalized = Math.max(-1, Math.min(1, (y - halfH) / Math.max(1, halfH)));
      return halfW * (1 - Math.sqrt(Math.max(0, 1 - normalized * normalized)));
    }
    function __afPanelRowBox(y, height) {
      const inset = Math.max(__afPanelCircleInset(y), __afPanelCircleInset(y + height));
      const x = Math.ceil(inset + __afPanelSafePad);
      const right = Math.floor(__afPanelW - inset - __afPanelSafePad);
      return { x: x, w: Math.max(1, right - x) };
    }
    function __afPanelSetVisible(w, visible) { w.setProperty(prop.VISIBLE, !!visible); }
    function __afPanelSetText(w, text, x, y, width, height) {
      w.setProperty(prop.MORE, { x: x, y: y, w: width, h: height, text: text });
    }
    function __afPanelSetRowText(w, text, y, height) {
      const box = __afPanelRowBox(y, height);
      __afPanelSetText(w, text, box.x, y, box.w, height);
    }
    function __afPanelButton(x, y, width, height, text, click) {
      const w = createWidget(widget.BUTTON, {
        show_level: show_level.ONLY_NORMAL,
        x: x, y: y, w: width, h: height, text: text,
        color: 0xffffff, text_size: __afPanelFont,
        normal_color: 0x253140, press_color: 0x3a4b60,
        radius: Math.max(4, Math.round(8 * __afPanelScale)),
        click_func: click,
      });
      __afPanelSetVisible(w, false);
      return w;
    }
    function __afPanelHour(value) { return (value < 10 ? '0' : '') + value + ':00'; }
    function __afPanelLargeRowHeight(y) { return Math.min(__afPanelRowH + 10, Math.max(1, __afPanelH - y)); }
    function __afPanelTimeRow(label, key, row, items, large) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = large ? __afPanelLargeRowHeight(y) : __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const desiredStepW = large ? Math.max(54, Math.round(72 * __afPanelScale)) : __afPanelStepW;
      const stepW = Math.min(desiredStepW, Math.max(20, Math.floor((box.w - 8) / 3)));
      const midW = Math.max(1, box.w - 2 * stepW - 4);
      const minus = __afPanelButton(box.x, y, stepW, h, '−', function () {
        __afProfilePrefs[key] = (__afProfilePrefs[key] + 23) % 24;
        __afProfileRefresh(); __afPanelRefresh();
      });
      const value = __afPanelButton(box.x + stepW + 2, y, midW, h, label, function () {});
      const plus = __afPanelButton(box.x + box.w - stepW, y, stepW, h, '+', function () {
        __afProfilePrefs[key] = (__afProfilePrefs[key] + 1) % 24;
        __afProfileRefresh(); __afPanelRefresh();
      });
      items.push(minus, value, plus);
      return { value: value, x: box.x + stepW + 2, y: y, w: midW, h: h };
    }
    function __afPanelRowButton(y, text, click, height) {
      const h = Math.min(height || __afPanelRowH - 2, Math.max(1, __afPanelH - y));
      const box = __afPanelRowBox(y, h);
      return __afPanelButton(box.x, y, box.w, h, text, click);
    }

    // The transparent screen-sized button makes the lower sheet modal while it is open.
    const __afPanelScrim = createWidget(widget.BUTTON, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: 0, w: __afPanelW, h: __afPanelH, text: '',
      normal_src: '', press_src: '', click_func: function () {},
    });
    __afPanelScrim.setAlpha(0);
    __afPanelSetVisible(__afPanelScrim, false);
    const __afPanelBg = createWidget(widget.FILL_RECT, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: __afPanelTop, w: __afPanelW, h: __afPanelHeight, color: 0x111923,
    });
    __afPanelSetVisible(__afPanelBg, false);
    const __afPanelHeaderY = __afPanelTop + __afPanelHeaderTop;
    const __afPanelHeaderInnerH = Math.max(20, __afPanelHeaderH - __afPanelHeaderTop - 2);
    const __afPanelHeaderBox = __afPanelRowBox(__afPanelHeaderY, __afPanelHeaderInnerH);
    // Слева небольшая шестерёнка (просто значок), справа крупная кнопка «Закрыть» с зазором от неё.
    const __afPanelHeaderGap = Math.max(8, Math.round(14 * __afPanelScale));
    const __afPanelGearW = Math.max(24, Math.min(Math.round(40 * __afPanelScale), Math.floor(__afPanelHeaderBox.w / 4)));
    const __afPanelCloseSize = Math.max(30, __afPanelHeaderBox.w - __afPanelGearW - __afPanelHeaderGap);
    const __afPanelTitle = __afPanelButton(__afPanelHeaderBox.x, __afPanelHeaderY, __afPanelGearW, __afPanelHeaderInnerH, '⚙', function () {});
    const __afPanelClose = __afPanelButton(__afPanelHeaderBox.x + __afPanelHeaderBox.w - __afPanelCloseSize, __afPanelHeaderY, __afPanelCloseSize, __afPanelHeaderInnerH, '×  Закрыть', function () {
      __afPanelVisible = false; __afPanelRefresh();
    });
    
    const __afProfileMenu = __afPanelRowButton(__afPanelRowY, 'День и ночь  ›', function () {
      __afPanelPage = 1; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY));
    const __afProfileDetails = [];
    const __afProfileMode = __afPanelRowButton(__afPanelRowY, '', function () {
      const modes = ['auto', 'day', 'night'];
      const i = modes.indexOf(__afProfilePrefs.profileMode);
      __afProfilePrefs.profileMode = modes[(i + 1 + modes.length) % modes.length];
      __afProfileRefresh(); __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY));
    __afProfileDetails.push(__afProfileMode);
    const __afProfileStart = __afPanelTimeRow('Ночной профиль с 22:00', 'profileStart', 2, __afProfileDetails, true);
    const __afProfileEnd = __afPanelTimeRow('Дневной профиль с 07:00', 'profileEnd', 4, __afProfileDetails, true);
    const __afProfileBack = __afPanelRowButton(__afPanelRowY + 9 * __afPanelRowH, '‹ Назад', function () {
      __afPanelPage = 0; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY + 9 * __afPanelRowH));
    __afProfileDetails.push(__afProfileBack);
    function __afPanelRefresh() {
      __afPanelSetVisible(__afPanelScrim, __afPanelVisible);
      __afPanelSetVisible(__afPanelBg, __afPanelVisible);
      __afPanelSetVisible(__afPanelTitle, __afPanelVisible);
      __afPanelSetVisible(__afPanelClose, __afPanelVisible);
      
      __afPanelSetVisible(__afProfileMenu, __afPanelVisible && __afPanelPage === 0);
      __afProfileDetails.forEach(function (w) { __afPanelSetVisible(w, __afPanelVisible && __afPanelPage === 1); });
      __afPanelSetText(__afPanelTitle, '⚙', __afPanelHeaderBox.x, __afPanelHeaderY, __afPanelGearW, __afPanelHeaderInnerH);
      
      __afPanelSetRowText(__afProfileMenu, 'День и ночь  ›', __afPanelRowY, __afPanelLargeRowHeight(__afPanelRowY));
      const profileNames = { auto: 'АВТО', day: 'ДЕНЬ', night: 'НОЧЬ' };
      __afPanelSetRowText(__afProfileMode, 'Режим циферблата: ' + (profileNames[__afProfilePrefs.profileMode] || 'АВТО'), __afPanelRowY, __afPanelLargeRowHeight(__afPanelRowY));
      __afPanelSetText(__afProfileStart.value, 'Ночной профиль с ' + __afPanelHour(__afProfilePrefs.profileStart), __afProfileStart.x, __afProfileStart.y, __afProfileStart.w, __afProfileStart.h);
      __afPanelSetText(__afProfileEnd.value, 'Дневной профиль с ' + __afPanelHour(__afProfilePrefs.profileEnd), __afProfileEnd.x, __afProfileEnd.y, __afProfileEnd.w, __afProfileEnd.h);
      __afPanelSetRowText(__afProfileBack, '‹ Назад', __afPanelRowY + 9 * __afPanelRowH, __afPanelLargeRowHeight(__afPanelRowY + 9 * __afPanelRowH));
      try { __afEdRefresh(); } catch (e) {}
      
    }
    function __afOpenSettings() {
      __afPanelVisible = true; __afPanelPage = 0; __afPanelRefresh();
    }
    // ---- Редактор текста на часах: список -> экран редактирования выбранного текста ----
    const __afEdPath = "amazface_edits_3848549_1794601475113.json";
    const __afEdSt = {};
    let __afEdSel = 0;
    let __afEdProfile = '';
    let __afEdPrev = false;
    let __afEdStep = 2;
    let __afEdListPage = 0;
    const __afEdPerPage = 6;
    const __afEdColors = [
      0xff3b30, 0xff9500, 0xffcc00, 0x34c759, 0x00c7be, 0x0a84ff, 0xbf5af2, 0xff2d92,
      0x000000, 0xffffff, 0xd0d0d0, 0x909090, 0x8e1b14, 0xa85d00, 0x1d7a34, 0x0050a8,
    ];
    function __afEdCurrentItems() {
      const night = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night';
      return __afEd.filter(function (it) { return (String(it.id).indexOf('night:') === 0) === night; });
    }
    function __afEdLoad() {
      try {
        const result = hmFS.stat(__afEdPath);
        if (!result || result[1] !== 0 || !result[0] || result[0].size <= 0 || result[0].size > 8192) return;
        const file = hmFS.open(__afEdPath, hmFS.O_RDONLY);
        if (typeof file !== 'number' || file < 0) return;
        try {
          const bytes = new Uint8Array(result[0].size);
          hmFS.read(file, bytes.buffer, 0, bytes.length);
          const data = JSON.parse(String.fromCharCode.apply(null, bytes));
          if (!data || typeof data !== 'object') return;
          for (let i = 0; i < __afEd.length; i++) {
            const v = data[__afEd[i].id];
            if (Array.isArray(v) && v.length === 4) __afEdSt[__afEd[i].id] = [Number(v[0]) || 0, Number(v[1]) || 0, Number(v[2]) || 0, Number(v[3]) >= 0 ? Number(v[3]) : -1];
          }
        } finally { hmFS.close(file); }
      } catch (e) {}
    }
    function __afEdSave() {
      let file = -1;
      try {
        const out = {};
        for (const id in __afEdSt) {
          const v = __afEdSt[id];
          if (v[0] !== 0 || v[1] !== 0 || v[2] !== 0 || v[3] >= 0) out[id] = v;
        }
        const raw = JSON.stringify(out);
        const bytes = new Uint8Array(raw.length);
        for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i) & 255;
        file = hmFS.open(__afEdPath, hmFS.O_RDWR | hmFS.O_CREAT | hmFS.O_TRUNC);
        if (typeof file === 'number' && file >= 0) hmFS.write(file, bytes.buffer, 0, bytes.length);
      } catch (e) {
      } finally {
        try { if (file >= 0) hmFS.close(file); } catch (e) {}
      }
    }
    function __afEdChanged(it) {
      const v = __afEdSt[it.id];
      return !!v && (v[0] !== 0 || v[1] !== 0 || v[2] !== 0 || v[3] >= 0);
    }
    function __afEdGeom(it) {
      const st = __afEdSt[it.id] || [0, 0, 0, -1];
      const ns = Math.max(8, Math.min(200, Math.round(it.s + st[2])));
      const nw = Math.max(1, Math.round(it.w * ns / it.s));
      const nh = Math.max(1, Math.round(it.ht * ns / it.s));
      let nx = it.x + st[0];
      if (it.ah === 'RIGHT') nx -= (nw - it.w);
      else if (it.ah !== 'LEFT') nx -= Math.floor((nw - it.w) / 2);
      const ny = it.y + st[1] - Math.floor((nh - it.ht) / 2);
      return { x: nx, y: ny, w: nw, h: nh, s: ns, c: st[3] >= 0 ? st[3] : it.c };
    }
    function __afEdApply(it) {
      const g = __afEdGeom(it);
      try { it.h.setProperty(prop.MORE, { x: g.x, y: g.y, w: g.w, h: g.h, text_size: g.s, color: g.c }); } catch (e) {}
    }
    function __afEdTouch(it) {
      return __afEdSt[it.id] || (__afEdSt[it.id] = [0, 0, 0, -1]);
    }
    function __afEdChange(k, d) {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      const st = __afEdTouch(it);
      st[k] += d;
      if (k === 2 && it.s + st[2] < 8) st[2] = 8 - it.s;
      if (k === 2 && it.s + st[2] > 200) st[2] = 200 - it.s;
      __afEdApply(it); __afEdSave(); __afPanelRefresh();
    }
    function __afEdSetColor(c) {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      __afEdTouch(it)[3] = c;
      __afEdApply(it); __afEdSave(); __afPanelRefresh();
    }
    function __afEdResetOne() {
      const it = __afEdCurrentItems()[__afEdSel];
      if (!it) return;
      delete __afEdSt[it.id];
      __afEdApply(it); __afEdSave(); __afPanelRefresh();
    }
    function __afEdResetAll() {
      const items = __afEdCurrentItems();
      for (let i = 0; i < items.length; i++) { delete __afEdSt[items[i].id]; __afEdApply(items[i]); }
      __afEdSave(); __afPanelRefresh();
    }
    __afEdLoad();
    (function () { for (let i = 0; i < __afEd.length; i++) { if (__afEdSt[__afEd[i].id]) __afEdApply(__afEd[i]); } })();

    // Страница 3 — список текстов, страница 4 — редактирование выбранного.
    const __afEdListAll = [];
    const __afEdEditAll = [];
    const __afEdStatic = [];
    function __afEdBtn(list, x, y, w, h, text, click) {
      const b = __afPanelButton(x, y, w, h, text, click);
      list.push(b);
      if (text) __afEdStatic.push({ w: b, t: text, x: x, y: y, bw: w, h: h });
      return b;
    }
    function __afEdTitle(list, row, color) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const w = createWidget(widget.TEXT, {
        show_level: show_level.ONLY_NORMAL,
        x: box.x, y: y, w: box.w, h: h, text: '',
        color: color, text_size: __afPanelFont,
        align_h: align.CENTER_H, align_v: align.CENTER_V,
      });
      __afPanelSetVisible(w, false);
      list.push(w);
      return { w: w, x: box.x, y: y, bw: box.w, h: h };
    }
    function __afEdFull(list, row, text, click) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const box = __afPanelRowBox(y, h);
      const b = __afEdBtn(list, box.x, y, box.w, h, text, click);
      return { w: b, x: box.x, y: y, bw: box.w, h: h };
    }
    // Общая ширина для нескольких строк: на круглом экране у каждой строки своя, а колонки должны быть ровными.
    function __afEdSharedBox(rows) {
      let left = 0, right = __afPanelW;
      rows.forEach(function (row) {
        const b = __afPanelRowBox(__afPanelRowY + row * __afPanelRowH, __afPanelRowH - 2);
        left = Math.max(left, b.x); right = Math.min(right, b.x + b.w);
      });
      return { x: left, w: Math.max(1, right - left) };
    }
    function __afEdHalves(list, row, textA, clickA, textB, clickB, shared) {
      const y = __afPanelRowY + row * __afPanelRowH;
      const h = __afPanelRowH - 2;
      const box = shared || __afPanelRowBox(y, h);
      const half = Math.floor((box.w - 4) / 2);
      const a = __afEdBtn(list, box.x, y, half, h, textA, clickA);
      const b = __afEdBtn(list, box.x + box.w - half, y, half, h, textB, clickB);
      return { a: a, b: b, ax: box.x, bx: box.x + box.w - half, y: y, bw: half, h: h };
    }
    function __afEdPages() { return Math.max(1, Math.ceil(__afEdCurrentItems().length / __afEdPerPage)); }

    const __afEdMenu = __afPanelRowButton(__afPanelRowY + 2 * __afPanelRowH, 'Редактор текста  ›', function () {
      __afEdSel = 0; __afEdListPage = 0; __afEdPrev = false; __afPanelPage = 3; __afPanelRefresh();
    }, __afPanelLargeRowHeight(__afPanelRowY + 2 * __afPanelRowH));

    // Список.
    const __afEdListTitle = __afEdTitle(__afEdListAll, 0, 0xffd60a);
    const __afEdItems = [];
    (function () {
      for (let slot = 0; slot < __afEdPerPage; slot++) {
        (function (sl) {
          const y = __afPanelRowY + (1 + sl) * __afPanelRowH;
          const h = __afPanelRowH - 2;
          const box = __afPanelRowBox(y, h);
          const b = __afEdBtn(__afEdListAll, box.x, y, box.w, h, '', function () {
            const idx = __afEdListPage * __afEdPerPage + sl;
            if (idx < __afEdCurrentItems().length) { __afEdSel = idx; __afEdPrev = false; __afPanelPage = 4; __afPanelRefresh(); }
          });
          __afEdItems.push({ w: b, x: box.x, y: y, bw: box.w, h: h });
        })(slot);
      }
    })();
    __afEdHalves(__afEdListAll, 7, '‹ Пред.', function () {
      __afEdListPage = (__afEdListPage + __afEdPages() - 1) % __afEdPages(); __afPanelRefresh();
    }, 'След. ›', function () {
      __afEdListPage = (__afEdListPage + 1) % __afEdPages(); __afPanelRefresh();
    });
    __afEdFull(__afEdListAll, 8, 'Сбросить все правки', function () { __afEdResetAll(); });
    __afEdFull(__afEdListAll, 9, '‹ Назад', function () {
      __afPanelPage = 0; __afPanelRefresh();
    });

    // Редактирование выбранного текста: две колонки крупных кнопок «−» и «+».
    const __afEdEditTitle = __afEdTitle(__afEdEditAll, 0, 0xffd60a);
    const __afEdValues = __afEdTitle(__afEdEditAll, 1, 0xffffff);
    (function () {
      const box = __afEdSharedBox([2, 3]);
      for (let r = 0; r < 2; r++) {
        const y = __afPanelRowY + (2 + r) * __afPanelRowH;
        const h = __afPanelRowH - 2;
        const gap = 2;
        const cw = Math.max(8, Math.floor((box.w - gap * 7) / 8));
        for (let c = 0; c < 8; c++) {
          (function (color) {
            const sw = createWidget(widget.BUTTON, {
              show_level: show_level.ONLY_NORMAL,
              x: box.x + c * (cw + gap), y: y, w: cw, h: h, text: '',
              normal_color: color, press_color: color,
              radius: Math.max(3, Math.round(6 * __afPanelScale)),
              click_func: function () { __afEdSetColor(color); },
            });
            __afPanelSetVisible(sw, false);
            __afEdEditAll.push(sw);
          })(__afEdColors[r * 8 + c]);
        }
      }
    })();
    const __afEdCtlBox = __afEdSharedBox([4, 5, 6]);
    __afEdHalves(__afEdEditAll, 4, '−  Размер', function () { __afEdChange(2, -__afEdStep); }, '+  Размер', function () { __afEdChange(2, __afEdStep); }, __afEdCtlBox);
    __afEdHalves(__afEdEditAll, 5, '−  X', function () { __afEdChange(0, -__afEdStep); }, '+  X', function () { __afEdChange(0, __afEdStep); }, __afEdCtlBox);
    __afEdHalves(__afEdEditAll, 6, '−  Y', function () { __afEdChange(1, -__afEdStep); }, '+  Y', function () { __afEdChange(1, __afEdStep); }, __afEdCtlBox);
    const __afEdRow7 = __afEdHalves(__afEdEditAll, 7, '', function () {
      __afEdStep = __afEdStep === 2 ? 5 : 2; __afPanelRefresh();
    }, 'Сбросить', function () { __afEdResetOne(); });
    __afEdFull(__afEdEditAll, 8, 'Показать на циферблате', function () {
      __afEdPrev = true; __afPanelRefresh();
    });
    __afEdFull(__afEdEditAll, 9, '‹ К списку', function () {
      __afPanelPage = 3; __afEdPrev = false; __afPanelRefresh();
    });
    const __afEdPrevList = [];
    const __afEdBackPrev = __afEdFull(__afEdPrevList, 9, '‹ К правкам', function () {
      __afEdPrev = false; __afPanelRefresh();
    });
    const __afEdFrame = createWidget(widget.STROKE_RECT, {
      show_level: show_level.ONLY_NORMAL,
      x: 0, y: 0, w: 10, h: 10, line_width: 2, color: 0xffd60a,
    });
    __afPanelSetVisible(__afEdFrame, false);

    function __afEdCut(text, n) {
      text = String(text);
      return text.length > n ? text.slice(0, n - 1) + '.' : text;
    }
    function __afEdRefresh() {
      const vis = __afPanelVisible;
      const activeProfile = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night' ? 'night' : 'day';
      if (__afEdProfile && __afEdProfile !== activeProfile && (__afPanelPage === 3 || __afPanelPage === 4)) {
        __afPanelPage = 3; __afEdSel = 0; __afEdListPage = 0; __afEdPrev = false;
      }
      __afEdProfile = activeProfile;
      const onList = vis && __afPanelPage === 3;
      const inEd = vis && __afPanelPage === 4;
      const onEd = inEd && !__afEdPrev;
      const currentItems = __afEdCurrentItems();
      if (__afEdSel >= currentItems.length) __afEdSel = 0;
      const it = currentItems[__afEdSel];
      __afPanelSetVisible(__afEdMenu, vis && __afPanelPage === 0);
      __afEdListAll.forEach(function (w) { __afPanelSetVisible(w, onList); });
      __afEdEditAll.forEach(function (w) { __afPanelSetVisible(w, onEd); });
      __afEdPrevList.forEach(function (w) { __afPanelSetVisible(w, inEd && __afEdPrev); });
      // Рамка только в режиме просмотра: поверх панели она перекрывала бы кнопки.
      __afPanelSetVisible(__afEdFrame, inEd && __afEdPrev && !!it);
      if (inEd && __afEdPrev) {
        __afPanelSetVisible(__afPanelBg, false);
        __afPanelSetVisible(__afPanelTitle, false);
        __afPanelSetVisible(__afPanelClose, false);
      }
      __afPanelSetRowText(__afEdMenu, 'Редактор текста  ›', __afPanelRowY + 2 * __afPanelRowH, __afPanelLargeRowHeight(__afPanelRowY + 2 * __afPanelRowH));
      __afEdStatic.forEach(function (r) { __afPanelSetText(r.w, r.t, r.x, r.y, r.bw, r.h); });
      if (onList) {
        const sceneName = typeof __afActiveProfile !== 'undefined' && __afActiveProfile === 'night' ? 'Ночь' : 'День';
        __afPanelSetText(__afEdListTitle.w, (currentItems.length ? 'Тексты: ' : 'Нет текстов: ') + sceneName + ' ' + (__afEdListPage + 1) + '/' + __afEdPages(), __afEdListTitle.x, __afEdListTitle.y, __afEdListTitle.bw, __afEdListTitle.h);
        for (let sl = 0; sl < __afEdItems.length; sl++) {
          const idx = __afEdListPage * __afEdPerPage + sl;
          const row = __afEdItems[sl];
          const item = currentItems[idx];
          if (!item) { __afPanelSetVisible(row.w, false); continue; }
          const label = (__afEdChanged(item) ? '* ' : '') + (idx + 1) + '. ' + item.n + (item.d ? ' - ' + item.d : '');
          __afPanelSetText(row.w, __afEdCut(label, 26), row.x, row.y, row.bw, row.h);
        }
      }
      if (inEd && it) {
        const g = __afEdGeom(it);
        try { __afEdFrame.setProperty(prop.MORE, { x: g.x - 2, y: g.y - 2, w: g.w + 4, h: g.h + 4 }); } catch (e) {}
      }
      if (onEd && it) {
        const g = __afEdGeom(it);
        const st = __afEdSt[it.id] || [0, 0, 0, -1];
        const sceneTag = activeProfile === 'night' ? ' [НОЧЬ]' : ' [ДЕНЬ]';
        __afPanelSetText(__afEdEditTitle.w, __afEdCut(it.n + (it.d ? ' - ' + it.d : '') + sceneTag, 26), __afEdEditTitle.x, __afEdEditTitle.y, __afEdEditTitle.bw, __afEdEditTitle.h);
        __afPanelSetText(__afEdValues.w, 'Размер ' + g.s + '   X ' + (it.x + st[0]) + '   Y ' + (it.y + st[1]), __afEdValues.x, __afEdValues.y, __afEdValues.bw, __afEdValues.h);
        __afPanelSetText(__afEdRow7.a, 'Шаг: ' + __afEdStep + ' px', __afEdRow7.ax, __afEdRow7.y, __afEdRow7.bw, __afEdRow7.h);
      }
    }
    
    __afPanelRefresh();
    __afProfileRefresh();
    self._dayNightTimer = setInterval(__afProfileRefresh, 30000);
    try { createWidget(widget.WIDGET_DELEGATE, { resume_call: function () { try { __afProfileRefresh(); } catch (e) {} } }); } catch (e) {}
  },
  onDestroy() {
    if (this._timeTimerNormal) { clearInterval(this._timeTimerNormal); this._timeTimerNormal = null; }
    if (this._sensorTimerNormal) { clearInterval(this._sensorTimerNormal); this._sensorTimerNormal = null; }
    if (this._smoothTimerNormal) { clearInterval(this._smoothTimerNormal); this._smoothTimerNormal = null; }
    if (this._timeTimerAod) { clearInterval(this._timeTimerAod); this._timeTimerAod = null; }
    if (this._sensorTimerAod) { clearInterval(this._sensorTimerAod); this._sensorTimerAod = null; }
    if (this._smoothTimerAod) { clearInterval(this._smoothTimerAod); this._smoothTimerAod = null; }
    if (this._timeTimerNight) { clearInterval(this._timeTimerNight); this._timeTimerNight = null; }
    if (this._sensorTimerNight) { clearInterval(this._sensorTimerNight); this._sensorTimerNight = null; }
    if (this._smoothTimerNight) { clearInterval(this._smoothTimerNight); this._smoothTimerNight = null; }
    if (this._dayNightTimer) { clearInterval(this._dayNightTimer); this._dayNightTimer = null; }
    try { __heartStop(); } catch (e) {}
    if (this._raiseTimer) { clearInterval(this._raiseTimer); this._raiseTimer = null; }
    if (this._screen && this._screenCb) { try { this._screen.offChange(this._screenCb); } catch (e) {} this._screen = null; this._screenCb = null; }
  },
});
